# NOVIQUE Deployment Guide

## Local / staging via Docker Compose
```bash
cp .env.example .env   # fill in real secrets
docker compose up --build
```
This brings up Postgres, Redis, the backend API (port 4000), and the Next.js frontend (port 3000). Run migrations once the DB container is healthy:
```bash
docker compose exec backend npx prisma migrate deploy
docker compose exec backend npm run seed   # optional sample data
```

## Production options

### Option A — Vercel (frontend) + a managed Node host (backend)
- Deploy `frontend/` to Vercel directly (it's a standard Next.js app). Set `NEXT_PUBLIC_API_URL` and `NEXT_PUBLIC_SITE_URL` in Vercel's env settings.
- Deploy `backend/` to Render, Railway, Fly.io, or an AWS ECS/Fargate service using the included `backend/Dockerfile`.
- Use a managed Postgres (Neon, Supabase, RDS) and managed Redis (Upstash, ElastiCache).
- Point `CLIENT_URL` (backend env) at your Vercel domain so CORS allows it.

### Option B — Full AWS / self-hosted with Nginx
- Build both Docker images (`docker build -t novique-backend ./backend`, same for frontend).
- Run behind Nginx as a reverse proxy — `backend/nginx.conf.example` is a starting config (TLS termination, `/api` → backend, `/` → frontend).
- Use RDS for Postgres, ElastiCache for Redis.
- Put Stripe webhook URL (`https://yourdomain.com/api/payments/stripe/webhook`) in the Stripe dashboard and copy the signing secret into `STRIPE_WEBHOOK_SECRET`.

## Required production env vars (see `.env.example` for the full list)
- `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` — generate with `openssl rand -hex 32`, never reuse dev values
- `DATABASE_URL`, `REDIS_URL`
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`
- `OPENAI_API_KEY`
- `CLIENT_URL` — must exactly match your deployed frontend origin (used for CORS + cookie scoping)

## Pre-launch checklist
- [ ] Run `npm audit` / Snyk on both `backend` and `frontend`
- [ ] Set `NODE_ENV=production` (enables secure cookies, strict env validation)
- [ ] Confirm Stripe webhook signature verification works against a real test event
- [ ] Load-test `/ai/*` routes — these are the most expensive (OpenAI latency + cost); tune `aiLimiter` accordingly
- [ ] Add a real tax/shipping provider (see `pricing.service.ts` comments) before processing real orders in multiple jurisdictions
- [ ] Set up automated Postgres backups
- [ ] Configure a CDN in front of Cloudinary-hosted product images
