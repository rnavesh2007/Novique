# NOVIQUE AI Architecture

The AI layer is split into two parts on purpose:

1. **Rule-based recommendation engine** (`backend/src/services/recommendation.service.ts`) — deterministic, explainable, free to run, no API key needed. Powers Compatibility Score, Complete the Look, Color Intelligence, and Size Recommendation.
2. **LLM layer** (`backend/src/services/openai.service.ts`) — used only where natural-language generation or open-ended conversation is genuinely needed: the personal shopper chatbot, occasion-outfit narration copy, and review summarization.

This split matters: a black-box LLM call for "is this shirt+jeans pairing good?" would be slower, costlier, non-deterministic, and harder to explain to a user than a transparent color-wheel + garment-pairing calculation. Save the LLM for things only an LLM can do well — open-ended advice and prose.

## Color Intelligence

`hexToHsl` converts a garment's primary color to HSL, then `classifyColorRelationship` buckets any pair of colors into one of: `neutral-pair`, `monochrome`, `analogous`, `complementary`, `triadic`, `clashing`, based on hue distance on the color wheel (with a saturation/lightness check to catch neutrals like black/white/grey, which pair with anything). Each bucket maps to a base score (0–100); see `COLOR_SCORE_BY_RELATIONSHIP`.

To extend: add seasonal-palette awareness by tagging products with a `season` field (already present: `Product.seasonality`) and biasing scores when the user's current season/location is known.

## Compatibility Score ("Complete the Look")

`computeCompatibility(a, b)` blends two signals:
- **Garment-pairing convention** (60% weight): a hand-authored graph (`PAIRING_GRAPH`) of which garment types are conventionally worn together (shirt↔jeans, dress↔heels, etc.)
- **Color theory** (40% weight): the score from above

This produces the "White Shirt + Jeans = 96% Match" style output, with a human-readable `reason` string. `completeTheLook()` in `ai.controller.ts` runs this against up to 200 same-gender candidate products and returns the top N — fine for a catalog of thousands, but swap in a proper vector search (pgvector, or an external ANN index) once the catalog grows past tens of thousands of SKUs, since the O(n) candidate scan won't hold up.

## Size Recommendation

`recommendSize()` is a BMI + body-type heuristic mapped to a generic S–XXL label. This is intentionally a starting point: real fit varies by brand and garment category. In production, replace the flat `order` array with per-category, per-vendor measurement charts and store a `sizeChartId` on `Product`, then look up against the user's actual measurements rather than a generic curve.

## Occasion Outfit Generator

`OCCASION_GARMENT_SLOTS` maps an occasion (office, wedding, festival, etc.) to the garment-type "slots" that make up a complete outfit for it. The generator fills each slot with the highest-`trendScore` matching product within budget, then asks the LLM for a 2–3 sentence styling note. Add more occasions by adding entries to this map — no code changes needed elsewhere.

## Trend Prediction (design, not yet implemented)

`Product.trendScore` is a real column, read by `GET /ai/trending`. To populate it for real:

1. Add a scheduled job (cron, or a queue worker) that runs e.g. hourly.
2. For each product, compute a weighted score from: recent order count (last 7/30 days), wishlist-add count, page-view count (you'll need to start logging views), and a recency decay so spikes fade.
3. Write the result back to `trendScore` via a bulk update.
4. Optionally split into "Trending Now" (short window, high weight on recency) vs. "Upcoming Trends" (longer window, weight on acceleration — rate of change rather than absolute volume).

## Visual Search (design, not yet implemented)

Contract is defined in `POST /ai/visual-search` (`ai.controller.ts`). To implement:

1. Accept an image upload (the route already accepts `multipart/form-data` via `multer`).
2. Call a vision-capable model (e.g. GPT-4o with an image input) with a prompt asking it to list detected garments, each with a `garmentType` and approximate `color`.
3. For each detected item, query the catalog (`Product.garmentType` + nearest `primaryColor` by hue distance — reuse `hexToHsl`/`hueDistance` from the recommendation service) for similar products.
4. Return `{ detectedItems, similarProducts }` matching the documented contract.

## AI Review Summarization

`summarizeReviews()` is called after every new review is submitted (`review.controller.ts`), re-summarizing all comments for that product into 2–3 neutral sentences. It's awaited inline for simplicity here; at scale, move this to a background queue (BullMQ + Redis, which is already a dependency) so review submission isn't blocked on an LLM call.
