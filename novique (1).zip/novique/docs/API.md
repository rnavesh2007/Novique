# NOVIQUE API Reference

Base URL: `http://localhost:4000/api` (dev) — all routes below are relative to this.
Auth: send `Authorization: Bearer <accessToken>` for protected routes. The refresh token lives in an httpOnly cookie, sent automatically by the browser.

## Auth — `/auth`
| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/signup` | — | `{ email, password, fullName }` |
| POST | `/login` | — | `{ email, password }` |
| POST | `/google` | — | `{ idToken }` from Google Identity Services |
| POST | `/verify-email` | — | `{ token, uid }` |
| POST | `/forgot-password` | — | `{ email }` |
| POST | `/reset-password` | — | `{ token, uid, newPassword }` |
| POST | `/refresh` | cookie | Issues a new access token |
| POST | `/logout` | cookie | Revokes the refresh token |
| GET | `/me` | required | Current user + style profile |

## Addresses — `/addresses` (auth required)
`GET /`, `POST /` (`{ label, line1, line2?, city, state, postalCode, country, phone, isDefault? }`), `DELETE /:id`

## Products — `/products`
`GET /` — query params: `category`, `gender`, `garmentType`, `q`, `minPrice`, `maxPrice`, `page`, `limit`
`GET /:slug` — full detail incl. variants + reviews
`POST /`, `PATCH /:id`, `DELETE /:id` — vendor/admin only

## Categories — `/categories`
`GET /` — top-level categories with children

## Cart — `/cart` (auth required)
`GET /`, `POST /` (`{ productId, variantId, quantity }`), `PATCH /:id` (`{ quantity?, savedForLater? }`), `DELETE /:id`

## Wishlist — `/wishlist` (auth required)
`GET /`, `POST /` (`{ productId }`), `POST /:id/move-to-cart` (`{ variantId, quantity? }`), `DELETE /:id`

## Wardrobe — `/wardrobe` (auth required)
`GET /`, `POST /` (`{ productId }`), `GET /combinations` — AI-generated pairings from owned items, `DELETE /:id`

## Orders — `/orders` (auth required)
`POST /` (`{ addressId, couponCode? }`) — places order from current cart
`GET /` — order history
`GET /:id` — single order detail
`POST /:id/cancel`
`POST /:id/return` (`{ reason, type: "return"|"exchange" }`)

## Coupons — `/coupons`
`POST /validate` (`{ code, subtotal }`) — public
`POST /` — admin only, create coupon

## Reviews — `/reviews`
`GET /product/:productId` — public
`POST /` (`{ productId, rating, comment?, photoUrls? }`) — auth required, purchase-gated

## Payments — `/payments` (auth required)
`POST /stripe/payment-intent` (`{ orderId }`) → `{ clientSecret }`
`POST /stripe/refund` (`{ orderId, amount? }`) — admin only
`POST /razorpay/order`, `POST /paypal/order` — stubs, see README
Webhook: `POST /api/payments/stripe/webhook` (not under `/payments` router — raw body, mounted directly in `index.ts`)

## AI — `/ai`
| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/style-profile` | required | Saves quiz answers, returns computed size |
| GET | `/complete-the-look/:productId` | — | `?limit=8` |
| POST | `/color-intelligence` | — | `{ colorA, colorB }` (hex) |
| POST | `/occasion-outfit` | — | `{ occasion, gender, budget? }` |
| GET | `/trending` | — | Top 12 by `trendScore` |
| POST | `/chat` | required | `{ sessionId?, message }` |
| POST | `/size-recommendation` | — | `{ heightCm, weightKg, bodyType? }` |
| POST | `/visual-search` | required | Stub — see AI_ARCHITECTURE.md |

## Admin — `/admin` (admin role required)
`GET /stats`, `GET /users`, `GET /orders`, `PATCH /orders/:id/status`, `GET /returns`, `PATCH /vendors/:id/approve`

## Vendor — `/vendor` (auth required)
`POST /register` (`{ storeName, description? }`)
`GET /dashboard`, `GET /products` — vendor/admin role required
