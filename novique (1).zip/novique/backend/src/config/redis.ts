import Redis from "ioredis";

// Used for: rate-limit counters, session/token blocklists, caching AI
// responses (compatibility scores, trend lists) that are expensive to compute.
const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379", {
  maxRetriesPerRequest: 3,
  lazyConnect: true,
});

redis.on("error", (err) => {
  console.error("[redis] connection error:", err.message);
});

export default redis;
