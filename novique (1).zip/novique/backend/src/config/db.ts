import { PrismaClient } from "@prisma/client";

// Single shared Prisma instance. Prisma uses parameterized queries internally,
// which is our primary defense against SQL injection — never build raw SQL
// strings from user input. If you must use $queryRaw, always use the
// tagged-template form (Prisma.sql`...`), never string concatenation.
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
});

export default prisma;
