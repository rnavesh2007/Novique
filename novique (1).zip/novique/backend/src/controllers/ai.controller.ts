import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";
import {
  computeCompatibility,
  colorCompatibilityScore,
  recommendSize,
  BodyType,
} from "../services/recommendation.service";
import {
  personalShopperChat,
  generateOccasionOutfitNarrative,
} from "../services/openai.service";

// ---------- Style Profile (AI Fashion Stylist intake) ----------

export const styleProfileSchema = z.object({
  gender: z.enum(["MALE", "FEMALE", "UNISEX", "KIDS"]).optional(),
  age: z.number().int().min(13).max(120).optional(),
  heightCm: z.number().min(100).max(250).optional(),
  weightKg: z.number().min(30).max(250).optional(),
  bodyType: z.enum(["SLIM", "ATHLETIC", "REGULAR", "CURVY", "PLUS_SIZE"]).optional(),
  favoriteColors: z.array(z.string()).default([]),
  preferredStyles: z.array(z.string()).default([]),
  budgetMin: z.number().int().nonnegative().optional(),
  budgetMax: z.number().int().nonnegative().optional(),
  occasionFocus: z.array(z.string()).default([]),
});

export async function saveStyleProfile(req: Request, res: Response) {
  const userId = req.user!.userId;
  const data = req.body as z.infer<typeof styleProfileSchema>;

  const recommendedSize =
    data.heightCm && data.weightKg
      ? recommendSize(data.heightCm, data.weightKg, data.bodyType as BodyType | undefined)
      : undefined;

  const profile = await prisma.styleProfile.upsert({
    where: { userId },
    create: { userId, ...data, recommendedSize },
    update: { ...data, recommendedSize },
  });

  res.json({ profile });
}

// ---------- Complete the Look ----------

export async function completeTheLook(req: Request, res: Response) {
  const { productId } = req.params;
  const limit = Math.min(parseInt((req.query.limit as string) || "8", 10), 20);

  const base = await prisma.product.findUnique({ where: { id: productId } });
  if (!base) throw new ApiError(404, "Product not found");

  // Candidate pool: active products of the same gender, excluding itself,
  // capped for performance — in production this would be a vector/ANN search
  // over embeddings, but garment-type + color rules give explainable results.
  const candidates = await prisma.product.findMany({
    where: { active: true, id: { not: base.id }, gender: base.gender },
    take: 200,
  });

  const scored = candidates
    .map((c) => {
      const { score, reason } = computeCompatibility(
        { garmentType: base.garmentType, primaryColor: base.primaryColor },
        { garmentType: c.garmentType, primaryColor: c.primaryColor }
      );
      return { product: c, score, reason };
    })
    .filter((s) => s.product.garmentType !== base.garmentType) // don't suggest another shirt for a shirt
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  res.json({
    base: { id: base.id, name: base.name, garmentType: base.garmentType },
    completeTheLook: scored,
  });
}

// ---------- Color Intelligence ----------

export const colorCheckSchema = z.object({
  colorA: z.string(),
  colorB: z.string(),
});

export async function colorIntelligence(req: Request, res: Response) {
  const { colorA, colorB } = req.body as z.infer<typeof colorCheckSchema>;
  const result = colorCompatibilityScore(colorA, colorB);
  res.json(result);
}

// ---------- Occasion Outfit Generator ----------

export const occasionSchema = z.object({
  occasion: z.string(), // "office" | "interview" | "wedding" | "casual" | "travel" | "date-night" | "festival" | "party" | "college"
  gender: z.enum(["MALE", "FEMALE", "UNISEX", "KIDS"]),
  budget: z.number().int().positive().optional(),
});

const OCCASION_GARMENT_SLOTS: Record<string, string[]> = {
  office: ["shirt", "trousers", "shoes", "belt", "watch"],
  interview: ["blazer", "shirt", "trousers", "shoes"],
  wedding: ["blazer", "shirt", "trousers", "shoes", "watch"],
  casual: ["t-shirt", "jeans", "sneakers"],
  travel: ["t-shirt", "jeans", "sneakers", "jacket"],
  "date-night": ["shirt", "trousers", "shoes", "watch"],
  festival: ["t-shirt", "shorts", "sneakers", "sunglasses"],
  party: ["shirt", "trousers", "shoes"],
  college: ["t-shirt", "jeans", "sneakers"],
};

export async function generateOccasionOutfit(req: Request, res: Response) {
  const { occasion, gender, budget } = req.body as z.infer<typeof occasionSchema>;
  const slots = OCCASION_GARMENT_SLOTS[occasion.toLowerCase()];
  if (!slots) {
    throw new ApiError(400, `Unsupported occasion. Try one of: ${Object.keys(OCCASION_GARMENT_SLOTS).join(", ")}`);
  }

  const picks = [];
  for (const garmentType of slots) {
    const priceFilter = budget ? { basePrice: { lte: budget / slots.length } } : {};
    const item = await prisma.product.findFirst({
      where: { active: true, gender, garmentType, ...priceFilter },
      orderBy: { trendScore: "desc" },
    });
    if (item) picks.push(item);
  }

  if (picks.length === 0) {
    return res.json({ occasion, items: [], narrative: "No matching products found in catalog yet for this occasion." });
  }

  let narrative = "";
  try {
    narrative = await generateOccasionOutfitNarrative({
      occasion,
      gender,
      items: picks.map((p) => ({ name: p.name, garmentType: p.garmentType })),
    });
  } catch {
    narrative = `A coordinated ${occasion} look built around ${picks.map((p) => p.garmentType).join(", ")}.`;
  }

  res.json({ occasion, items: picks, narrative });
}

// ---------- Trending ----------

export async function trending(_req: Request, res: Response) {
  // trendScore is updated by a periodic job (see docs/AI_ARCHITECTURE.md) that
  // factors in recent order volume, wishlist adds, and view counts. Here we
  // just read the cached score for fast responses.
  const trendingNow = await prisma.product.findMany({
    where: { active: true },
    orderBy: { trendScore: "desc" },
    take: 12,
  });
  res.json({ trendingNow });
}

// ---------- Personal Shopper Chatbot ----------

export const chatSchema = z.object({
  sessionId: z.string().optional(),
  message: z.string().min(1).max(2000),
});

export async function chat(req: Request, res: Response) {
  const userId = req.user!.userId;
  const { sessionId, message } = req.body as z.infer<typeof chatSchema>;

  const session = sessionId
    ? await prisma.chatSession.findFirst({ where: { id: sessionId, userId } })
    : await prisma.chatSession.create({ data: { userId } });

  if (!session) throw new ApiError(404, "Chat session not found");

  await prisma.chatMessage.create({ data: { sessionId: session.id, role: "user", content: message } });

  const history = await prisma.chatMessage.findMany({
    where: { sessionId: session.id },
    orderBy: { createdAt: "asc" },
    take: 20,
  });

  const reply = await personalShopperChat(history.map((h) => ({ role: h.role as "user" | "assistant", content: h.content })));

  await prisma.chatMessage.create({ data: { sessionId: session.id, role: "assistant", content: reply } });

  res.json({ sessionId: session.id, reply });
}

// ---------- Size Recommendation ----------

export const sizeSchema = z.object({
  heightCm: z.number().min(100).max(250),
  weightKg: z.number().min(30).max(250),
  bodyType: z.enum(["SLIM", "ATHLETIC", "REGULAR", "CURVY", "PLUS_SIZE"]).optional(),
});

export async function sizeRecommendation(req: Request, res: Response) {
  const { heightCm, weightKg, bodyType } = req.body as z.infer<typeof sizeSchema>;
  const size = recommendSize(heightCm, weightKg, bodyType as BodyType | undefined);
  res.json({ recommendedSize: size });
}

// ---------- Visual Search (stub) ----------

export async function visualSearch(_req: Request, res: Response) {
  // Real implementation needs: (1) an image upload endpoint (multer +
  // Cloudinary, already wired for products), (2) a vision model call (e.g.
  // GPT-4o with image input, or a CLIP-based embedding + ANN index) to
  // detect garment regions and describe each, (3) a catalog search over
  // garmentType + primaryColor + style tags using those descriptions. This
  // stub documents the contract so the frontend can be built against it now.
  res.status(501).json({
    error: "Visual search requires a configured vision model and image pipeline.",
    contract: {
      request: "multipart/form-data with field 'image'",
      response: { detectedItems: [{ garmentType: "string", color: "string", confidence: "number" }], similarProducts: "Product[]" },
    },
  });
}
