import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";

export async function listProducts(req: Request, res: Response) {
  const { category, gender, garmentType, q, minPrice, maxPrice, page = "1", limit = "24" } = req.query as Record<string, string>;

  const where: any = { active: true };
  if (category) where.category = { slug: category };
  if (gender) where.gender = gender;
  if (garmentType) where.garmentType = garmentType;
  if (q) where.name = { contains: q, mode: "insensitive" }; // Prisma parameterizes this safely — no raw SQL
  if (minPrice || maxPrice) {
    where.basePrice = {};
    if (minPrice) where.basePrice.gte = parseFloat(minPrice);
    if (maxPrice) where.basePrice.lte = parseFloat(maxPrice);
  }

  const pageNum = Math.max(1, parseInt(page, 10));
  const limitNum = Math.min(60, Math.max(1, parseInt(limit, 10)));

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: { category: true, variants: true },
      skip: (pageNum - 1) * limitNum,
      take: limitNum,
      orderBy: { createdAt: "desc" },
    }),
    prisma.product.count({ where }),
  ]);

  res.json({ items, total, page: pageNum, pages: Math.ceil(total / limitNum) });
}

export async function getProduct(req: Request, res: Response) {
  const product = await prisma.product.findUnique({
    where: { slug: req.params.slug },
    include: {
      category: true,
      variants: true,
      reviews: { include: { user: { select: { fullName: true } } }, orderBy: { createdAt: "desc" }, take: 10 },
    },
  });
  if (!product) throw new ApiError(404, "Product not found");
  res.json({ product });
}

export const createProductSchema = z.object({
  name: z.string().min(1),
  slug: z.string().min(1),
  description: z.string().min(1),
  categoryId: z.string(),
  gender: z.enum(["MALE", "FEMALE", "UNISEX", "KIDS"]),
  basePrice: z.number().positive(),
  discountPrice: z.number().positive().optional(),
  primaryColor: z.string(),
  secondaryColors: z.array(z.string()).default([]),
  garmentType: z.string(),
  seasonality: z.array(z.string()).default([]),
  occasionTags: z.array(z.string()).default([]),
  images: z.array(z.string()).default([]),
  variants: z.array(z.object({ size: z.string(), color: z.string(), sku: z.string(), stock: z.number().int().nonnegative() })),
});

export async function createProduct(req: Request, res: Response) {
  const data = req.body as z.infer<typeof createProductSchema>;
  const vendor = await prisma.vendor.findUnique({ where: { userId: req.user!.userId } });

  const product = await prisma.product.create({
    data: {
      ...data,
      vendorId: vendor?.id,
      variants: { create: data.variants },
    },
    include: { variants: true },
  });
  res.status(201).json({ product });
}

export async function updateProduct(req: Request, res: Response) {
  const product = await prisma.product.update({ where: { id: req.params.id }, data: req.body });
  res.json({ product });
}

export async function deleteProduct(req: Request, res: Response) {
  await prisma.product.update({ where: { id: req.params.id }, data: { active: false } }); // soft delete
  res.json({ message: "Product deactivated" });
}
