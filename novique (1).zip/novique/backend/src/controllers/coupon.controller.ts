import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";

export async function validateCoupon(req: Request, res: Response) {
  const { code, subtotal } = req.body as { code: string; subtotal: number };
  const coupon = await prisma.coupon.findUnique({ where: { code } });
  if (!coupon || !coupon.active) return res.json({ valid: false, reason: "Coupon not found or inactive" });
  if (coupon.expiresAt && coupon.expiresAt < new Date()) return res.json({ valid: false, reason: "Coupon expired" });
  if (coupon.minOrderValue && subtotal < Number(coupon.minOrderValue))
    return res.json({ valid: false, reason: `Minimum order value is ${coupon.minOrderValue}` });
  if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) return res.json({ valid: false, reason: "Coupon usage limit reached" });
  res.json({ valid: true, coupon });
}

export const createCouponSchema = z.object({
  code: z.string().min(3),
  discountType: z.enum(["PERCENTAGE", "FIXED"]),
  discountValue: z.number().positive(),
  minOrderValue: z.number().positive().optional(),
  maxUses: z.number().int().positive().optional(),
  expiresAt: z.string().datetime().optional(),
});

export async function createCoupon(req: Request, res: Response) {
  const data = req.body as z.infer<typeof createCouponSchema>;
  const coupon = await prisma.coupon.create({
    data: { ...data, expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined },
  });
  res.status(201).json({ coupon });
}
