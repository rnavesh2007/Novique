import { Request, Response } from "express";
import prisma from "../config/db";

export async function getWishlist(req: Request, res: Response) {
  const items = await prisma.wishlistItem.findMany({ where: { userId: req.user!.userId }, include: { product: true } });
  res.json({ items });
}

export async function addToWishlist(req: Request, res: Response) {
  const { productId } = req.body as { productId: string };
  const item = await prisma.wishlistItem.upsert({
    where: { userId_productId: { userId: req.user!.userId, productId } },
    create: { userId: req.user!.userId, productId },
    update: {},
  });
  res.status(201).json({ item });
}

export async function removeFromWishlist(req: Request, res: Response) {
  await prisma.wishlistItem.delete({ where: { id: req.params.id } });
  res.json({ message: "Removed from wishlist" });
}

// Move item to cart in one call: needs a variantId since wishlist isn't size-specific.
export async function moveToCart(req: Request, res: Response) {
  const { variantId, quantity = 1 } = req.body as { variantId: string; quantity?: number };
  const wishlistItem = await prisma.wishlistItem.findUnique({ where: { id: req.params.id } });
  if (!wishlistItem) return res.status(404).json({ error: "Wishlist item not found" });

  await prisma.$transaction([
    prisma.cartItem.upsert({
      where: { userId_variantId: { userId: req.user!.userId, variantId } },
      create: { userId: req.user!.userId, productId: wishlistItem.productId, variantId, quantity },
      update: { quantity: { increment: quantity } },
    }),
    prisma.wishlistItem.delete({ where: { id: wishlistItem.id } }),
  ]);

  res.json({ message: "Moved to cart" });
}
