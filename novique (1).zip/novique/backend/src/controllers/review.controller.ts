import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";
import { summarizeReviews } from "../services/openai.service";

export const createReviewSchema = z.object({
  productId: z.string(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(2000).optional(),
  photoUrls: z.array(z.string().url()).default([]),
});

export async function createReview(req: Request, res: Response) {
  const userId = req.user!.userId;
  const data = req.body as z.infer<typeof createReviewSchema>;

  // Require a delivered order containing this product — guards against fake reviews.
  const purchased = await prisma.orderItem.findFirst({
    where: { productId: data.productId, order: { userId, status: "DELIVERED" } },
  });
  if (!purchased) throw new ApiError(403, "You can only review products you've purchased and received");

  const review = await prisma.review.upsert({
    where: { userId_productId: { userId, productId: data.productId } },
    create: { userId, ...data },
    update: { rating: data.rating, comment: data.comment, photoUrls: data.photoUrls },
  });

  // Refresh the AI summary for this product in the background-ish (awaited
  // here for simplicity; move to a queue/worker for production scale).
  try {
    const allComments = await prisma.review.findMany({
      where: { productId: data.productId, comment: { not: null } },
      select: { comment: true },
      take: 50,
    });
    const summary = await summarizeReviews(allComments.map((r) => r.comment!).filter(Boolean));
    if (summary) {
      await prisma.review.updateMany({ where: { productId: data.productId }, data: { aiSummary: summary } });
    }
  } catch {
    // AI summarization is best-effort — never block the review submission on it.
  }

  res.status(201).json({ review });
}

export async function listReviewsForProduct(req: Request, res: Response) {
  const reviews = await prisma.review.findMany({
    where: { productId: req.params.productId },
    include: { user: { select: { fullName: true } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ reviews });
}
