import { Request, Response } from "express";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";

export async function registerVendor(req: Request, res: Response) {
  const { storeName, description } = req.body as { storeName: string; description?: string };
  const vendor = await prisma.vendor.upsert({
    where: { userId: req.user!.userId },
    create: { userId: req.user!.userId, storeName, description },
    update: { storeName, description },
  });

  await prisma.user.update({ where: { id: req.user!.userId }, data: { role: "VENDOR" } });
  res.status(201).json({ vendor });
}

export async function vendorDashboard(req: Request, res: Response) {
  const vendor = await prisma.vendor.findUnique({ where: { userId: req.user!.userId } });
  if (!vendor) throw new ApiError(404, "Vendor profile not found");

  const [productCount, orderItems] = await Promise.all([
    prisma.product.count({ where: { vendorId: vendor.id } }),
    prisma.orderItem.findMany({
      where: { product: { vendorId: vendor.id } },
      include: { order: true, product: true },
    }),
  ]);

  const revenue = orderItems
    .filter((i) => i.order.status !== "CANCELLED")
    .reduce((sum, i) => sum + Number(i.unitPrice) * i.quantity, 0);

  res.json({ vendor, productCount, revenue, recentOrderItems: orderItems.slice(0, 20) });
}

export async function vendorProducts(req: Request, res: Response) {
  const vendor = await prisma.vendor.findUnique({ where: { userId: req.user!.userId } });
  if (!vendor) throw new ApiError(404, "Vendor profile not found");
  const products = await prisma.product.findMany({ where: { vendorId: vendor.id }, include: { variants: true } });
  res.json({ products });
}
