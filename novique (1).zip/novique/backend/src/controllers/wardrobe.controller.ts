import { Request, Response } from "express";
import prisma from "../config/db";
import { computeCompatibility } from "../services/recommendation.service";

export async function getWardrobe(req: Request, res: Response) {
  const items = await prisma.wardrobeItem.findMany({ where: { userId: req.user!.userId }, include: { product: true } });
  res.json({ items });
}

export async function addToWardrobe(req: Request, res: Response) {
  const { productId } = req.body as { productId: string };
  const item = await prisma.wardrobeItem.upsert({
    where: { userId_productId: { userId: req.user!.userId, productId } },
    create: { userId: req.user!.userId, productId },
    update: {},
  });
  res.status(201).json({ item });
}

// Generates new outfit combinations purely from what the user already owns.
export async function generateFromWardrobe(req: Request, res: Response) {
  const items = await prisma.wardrobeItem.findMany({ where: { userId: req.user!.userId }, include: { product: true } });
  const products = items.map((i) => i.product);

  const pairs: { a: string; b: string; score: number; reason: string }[] = [];
  for (let i = 0; i < products.length; i++) {
    for (let j = i + 1; j < products.length; j++) {
      if (products[i].garmentType === products[j].garmentType) continue;
      const { score, reason } = computeCompatibility(products[i], products[j]);
      if (score >= 75) pairs.push({ a: products[i].id, b: products[j].id, score, reason });
    }
  }
  pairs.sort((x, y) => y.score - x.score);

  res.json({ combinations: pairs.slice(0, 15) });
}

export async function removeFromWardrobe(req: Request, res: Response) {
  await prisma.wardrobeItem.delete({ where: { id: req.params.id } });
  res.json({ message: "Removed from wardrobe" });
}
