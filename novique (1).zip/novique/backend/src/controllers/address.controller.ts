import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";

export const addressSchema = z.object({
  label: z.string().default("Home"),
  line1: z.string().min(1),
  line2: z.string().optional(),
  city: z.string().min(1),
  state: z.string().min(1),
  postalCode: z.string().min(1),
  country: z.string().min(1),
  phone: z.string().min(1),
  isDefault: z.boolean().default(false),
});

export async function listAddresses(req: Request, res: Response) {
  const addresses = await prisma.address.findMany({ where: { userId: req.user!.userId }, orderBy: { isDefault: "desc" } });
  res.json({ addresses });
}

export async function createAddress(req: Request, res: Response) {
  const data = req.body as z.infer<typeof addressSchema>;
  const userId = req.user!.userId;

  if (data.isDefault) {
    await prisma.address.updateMany({ where: { userId }, data: { isDefault: false } });
  }
  const address = await prisma.address.create({ data: { ...data, userId } });
  res.status(201).json({ address });
}

export async function deleteAddress(req: Request, res: Response) {
  await prisma.address.delete({ where: { id: req.params.id } });
  res.json({ message: "Address removed" });
}
