import { Request, Response } from "express";
import Stripe from "stripe";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";
import { env } from "../config/env";

const stripe = env.stripe.secretKey ? new Stripe(env.stripe.secretKey, { apiVersion: "2024-06-20" }) : null;

function ensureStripe(): Stripe {
  if (!stripe) throw new ApiError(500, "Stripe is not configured. Set STRIPE_SECRET_KEY.");
  return stripe;
}

// ---------- Stripe ----------

export async function createStripePaymentIntent(req: Request, res: Response) {
  const { orderId } = req.body as { orderId: string };
  const order = await prisma.order.findFirst({ where: { id: orderId, userId: req.user!.userId } });
  if (!order) throw new ApiError(404, "Order not found");

  const client = ensureStripe();
  const intent = await client.paymentIntents.create({
    amount: Math.round(Number(order.totalAmount) * 100), // Stripe uses smallest currency unit
    currency: "usd",
    metadata: { orderId: order.id, orderNumber: order.orderNumber },
    automatic_payment_methods: { enabled: true },
  });

  await prisma.payment.upsert({
    where: { orderId: order.id },
    create: { orderId: order.id, provider: "STRIPE", providerRef: intent.id, amount: order.totalAmount, status: "PENDING" },
    update: { providerRef: intent.id, status: "PENDING" },
  });

  res.json({ clientSecret: intent.client_secret });
}

// Stripe requires the *raw* request body (not JSON-parsed) to verify the
// webhook signature, so this handler is mounted in index.ts with
// express.raw() BEFORE the global express.json() middleware — see index.ts.
export async function stripeWebhook(req: Request, res: Response) {
  const client = ensureStripe();
  const signature = req.headers["stripe-signature"] as string;

  let event: Stripe.Event;
  try {
    event = client.webhooks.constructEvent(req.body, signature, env.stripe.webhookSecret);
  } catch (err) {
    return res.status(400).send(`Webhook signature verification failed`);
  }

  if (event.type === "payment_intent.succeeded") {
    const intent = event.data.object as Stripe.PaymentIntent;
    const orderId = intent.metadata.orderId;
    await prisma.$transaction([
      prisma.payment.update({ where: { orderId }, data: { status: "SUCCEEDED" } }),
      prisma.order.update({ where: { id: orderId }, data: { status: "CONFIRMED" } }),
    ]);
  } else if (event.type === "payment_intent.payment_failed") {
    const intent = event.data.object as Stripe.PaymentIntent;
    await prisma.payment.update({ where: { orderId: intent.metadata.orderId }, data: { status: "FAILED" } });
  }

  res.json({ received: true });
}

export async function refundStripePayment(req: Request, res: Response) {
  const { orderId, amount } = req.body as { orderId: string; amount?: number };
  const payment = await prisma.payment.findUnique({ where: { orderId } });
  if (!payment || payment.provider !== "STRIPE") throw new ApiError(400, "No Stripe payment found for this order");

  const client = ensureStripe();
  const refund = await client.refunds.create({
    payment_intent: payment.providerRef,
    ...(amount && { amount: Math.round(amount * 100) }),
  });

  await prisma.payment.update({
    where: { orderId },
    data: { status: "REFUNDED", refundedAmount: amount ?? payment.amount },
  });

  res.json({ refund });
}

// ---------- Razorpay (stub) ----------
// Wire up with: npm i razorpay (already in package.json), instantiate with
// RAZORPAY_KEY_ID/SECRET, call razorpayInstance.orders.create({amount, currency}),
// return the order id to the frontend's Razorpay Checkout widget, and verify
// the payment signature server-side on the success callback before marking paid.
export async function createRazorpayOrder(req: Request, res: Response) {
  if (!env.razorpay.keyId) {
    throw new ApiError(501, "Razorpay is not configured. Set RAZORPAY_KEY_ID/RAZORPAY_KEY_SECRET to enable this gateway.");
  }
  res.status(501).json({ error: "Razorpay integration scaffolded — add credentials and complete createRazorpayOrder()." });
}

// ---------- PayPal (stub) ----------
// Wire up with PayPal's Orders v2 API: POST /v2/checkout/orders to create,
// then capture via POST /v2/checkout/orders/{id}/capture after approval.
export async function createPaypalOrder(req: Request, res: Response) {
  res.status(501).json({ error: "PayPal integration scaffolded — add PAYPAL_CLIENT_ID/SECRET and implement Orders v2 calls." });
}
