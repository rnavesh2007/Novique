import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";
import { calculateTax, calculateShipping, applyDiscount } from "../services/pricing.service";

export const placeOrderSchema = z.object({
  addressId: z.string(),
  couponCode: z.string().optional(),
});

function generateOrderNumber(): string {
  return `NQ-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 1000)}`;
}

export async function placeOrder(req: Request, res: Response) {
  const userId = req.user!.userId;
  const { addressId, couponCode } = req.body as z.infer<typeof placeOrderSchema>;

  const address = await prisma.address.findFirst({ where: { id: addressId, userId } });
  if (!address) throw new ApiError(400, "Address not found");

  const cartItems = await prisma.cartItem.findMany({
    where: { userId, savedForLater: false },
    include: { product: true, variant: true },
  });
  if (cartItems.length === 0) throw new ApiError(400, "Cart is empty");

  // Re-check stock at checkout time to avoid overselling between add-to-cart and purchase.
  for (const item of cartItems) {
    if (item.variant.stock < item.quantity) {
      throw new ApiError(409, `${item.product.name} (${item.variant.size}/${item.variant.color}) is out of stock`);
    }
  }

  const subtotal = cartItems.reduce((sum, i) => sum + Number(i.product.discountPrice ?? i.product.basePrice) * i.quantity, 0);

  let coupon = null;
  if (couponCode) {
    coupon = await prisma.coupon.findUnique({ where: { code: couponCode } });
    if (!coupon || !coupon.active || (coupon.expiresAt && coupon.expiresAt < new Date())) {
      throw new ApiError(400, "Invalid or expired coupon");
    }
    if (coupon.minOrderValue && subtotal < Number(coupon.minOrderValue)) {
      throw new ApiError(400, `Coupon requires a minimum order of ${coupon.minOrderValue}`);
    }
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
      throw new ApiError(400, "Coupon has reached its usage limit");
    }
  }

  const discountAmount = coupon
    ? applyDiscount(subtotal, { discountType: coupon.discountType, discountValue: Number(coupon.discountValue) })
    : 0;
  const taxAmount = calculateTax(subtotal - discountAmount);
  const shippingCost = calculateShipping(subtotal - discountAmount);
  const totalAmount = subtotal - discountAmount + taxAmount + shippingCost;

  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        orderNumber: generateOrderNumber(),
        userId,
        addressId,
        subtotal,
        taxAmount,
        shippingCost,
        discountAmount,
        totalAmount,
        couponId: coupon?.id,
        items: {
          create: cartItems.map((i) => ({
            productId: i.productId,
            variantId: i.variantId,
            quantity: i.quantity,
            unitPrice: i.product.discountPrice ?? i.product.basePrice,
          })),
        },
      },
      include: { items: true },
    });

    // Decrement stock per variant.
    for (const item of cartItems) {
      await tx.productVariant.update({ where: { id: item.variantId }, data: { stock: { decrement: item.quantity } } });
    }

    if (coupon) {
      await tx.coupon.update({ where: { id: coupon.id }, data: { usedCount: { increment: 1 } } });
    }

    await tx.cartItem.deleteMany({ where: { userId, savedForLater: false } });

    return created;
  });

  res.status(201).json({ order });
}

export async function listOrders(req: Request, res: Response) {
  const orders = await prisma.order.findMany({
    where: { userId: req.user!.userId },
    include: { items: { include: { product: true } }, payment: true },
    orderBy: { createdAt: "desc" },
  });
  res.json({ orders });
}

export async function getOrder(req: Request, res: Response) {
  const order = await prisma.order.findFirst({
    where: { id: req.params.id, userId: req.user!.userId },
    include: { items: { include: { product: true, variant: true } }, payment: true, address: true },
  });
  if (!order) throw new ApiError(404, "Order not found");
  res.json({ order });
}

export async function cancelOrder(req: Request, res: Response) {
  const order = await prisma.order.findFirst({ where: { id: req.params.id, userId: req.user!.userId } });
  if (!order) throw new ApiError(404, "Order not found");
  if (["SHIPPED", "OUT_FOR_DELIVERY", "DELIVERED"].includes(order.status)) {
    throw new ApiError(400, "Order can no longer be cancelled — it's already shipped. Consider a return instead.");
  }
  const updated = await prisma.order.update({ where: { id: order.id }, data: { status: "CANCELLED" } });
  res.json({ order: updated });
}

export const returnRequestSchema = z.object({
  reason: z.string().min(1),
  type: z.enum(["return", "exchange"]).default("return"),
});

export async function requestReturn(req: Request, res: Response) {
  const order = await prisma.order.findFirst({ where: { id: req.params.id, userId: req.user!.userId } });
  if (!order) throw new ApiError(404, "Order not found");
  if (order.status !== "DELIVERED") throw new ApiError(400, "Only delivered orders are eligible for return/exchange");

  const { reason, type } = req.body as z.infer<typeof returnRequestSchema>;
  const returnRequest = await prisma.returnRequest.create({ data: { orderId: order.id, reason, type } });
  res.status(201).json({ returnRequest });
}
