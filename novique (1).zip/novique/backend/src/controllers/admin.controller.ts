import { Request, Response } from "express";
import prisma from "../config/db";

export async function dashboardStats(_req: Request, res: Response) {
  const [userCount, productCount, orderCount, revenueAgg, pendingReturns] = await Promise.all([
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.product.count({ where: { active: true } }),
    prisma.order.count(),
    prisma.order.aggregate({ _sum: { totalAmount: true }, where: { status: { not: "CANCELLED" } } }),
    prisma.returnRequest.count({ where: { status: "requested" } }),
  ]);

  res.json({
    userCount,
    productCount,
    orderCount,
    totalRevenue: revenueAgg._sum.totalAmount || 0,
    pendingReturns,
  });
}

export async function listUsers(req: Request, res: Response) {
  const users = await prisma.user.findMany({
    select: { id: true, email: true, fullName: true, role: true, emailVerified: true, createdAt: true },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ users });
}

export async function listAllOrders(req: Request, res: Response) {
  const orders = await prisma.order.findMany({
    include: { user: { select: { fullName: true, email: true } }, items: true },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ orders });
}

export async function updateOrderStatus(req: Request, res: Response) {
  const { status } = req.body as { status: string };
  const order = await prisma.order.update({ where: { id: req.params.id }, data: { status: status as any } });
  res.json({ order });
}

export async function listReturns(_req: Request, res: Response) {
  const returns = await prisma.returnRequest.findMany({
    include: { order: { include: { user: { select: { fullName: true, email: true } } } } },
    orderBy: { createdAt: "desc" },
  });
  res.json({ returns });
}

export async function approveVendor(req: Request, res: Response) {
  const vendor = await prisma.vendor.update({ where: { id: req.params.id }, data: { approved: true } });
  res.json({ vendor });
}
