import { Request, Response } from "express";
import { z } from "zod";
import prisma from "../config/db";
import { ApiError } from "../middleware/error.middleware";

export async function getCart(req: Request, res: Response) {
  const items = await prisma.cartItem.findMany({
    where: { userId: req.user!.userId, savedForLater: false },
    include: { product: true, variant: true },
  });
  res.json({ items });
}

export const addToCartSchema = z.object({
  productId: z.string(),
  variantId: z.string(),
  quantity: z.number().int().positive().default(1),
});

export async function addToCart(req: Request, res: Response) {
  const { productId, variantId, quantity } = req.body as z.infer<typeof addToCartSchema>;
  const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
  if (!variant || variant.productId !== productId) throw new ApiError(400, "Invalid product/variant");
  if (variant.stock < quantity) throw new ApiError(409, "Not enough stock available");

  const item = await prisma.cartItem.upsert({
    where: { userId_variantId: { userId: req.user!.userId, variantId } },
    create: { userId: req.user!.userId, productId, variantId, quantity },
    update: { quantity: { increment: quantity } },
  });
  res.status(201).json({ item });
}

export async function updateCartItem(req: Request, res: Response) {
  const { quantity, savedForLater } = req.body as { quantity?: number; savedForLater?: boolean };
  const item = await prisma.cartItem.update({
    where: { id: req.params.id },
    data: { ...(quantity !== undefined && { quantity }), ...(savedForLater !== undefined && { savedForLater }) },
  });
  res.json({ item });
}

export async function removeCartItem(req: Request, res: Response) {
  await prisma.cartItem.delete({ where: { id: req.params.id } });
  res.json({ message: "Removed from cart" });
}
