import { Request, Response } from "express";
import crypto from "crypto";
import { z } from "zod";
import prisma from "../config/db";
import { hashPassword, comparePassword, isPasswordStrongEnough } from "../utils/password";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../utils/jwt";
import { verifyGoogleIdToken } from "../services/google.service";
import { sendEmail, verificationEmailHtml, passwordResetEmailHtml } from "../services/email.service";
import { ApiError } from "../middleware/error.middleware";
import { env } from "../config/env";

export const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(1).max(120),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const REFRESH_COOKIE = "novique_refresh";

function setRefreshCookie(res: Response, token: string) {
  res.cookie(REFRESH_COOKIE, token, {
    httpOnly: true,
    secure: env.nodeEnv === "production",
    sameSite: "lax",
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    path: "/api/auth",
  });
}

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function signup(req: Request, res: Response) {
  const { email, password, fullName } = req.body;

  if (!isPasswordStrongEnough(password)) {
    throw new ApiError(400, "Password must be at least 8 characters and include a letter and a number");
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw new ApiError(409, "An account with this email already exists");
  }

  const passwordHash = await hashPassword(password);
  const rawVerifyToken = crypto.randomBytes(32).toString("hex");

  const user = await prisma.user.create({
    data: {
      email,
      passwordHash,
      fullName,
      emailVerifyTokenHash: hashToken(rawVerifyToken),
      emailVerifyExpires: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });

  const verifyLink = `${env.clientUrl}/verify-email?token=${rawVerifyToken}&uid=${user.id}`;
  await sendEmail(email, "Verify your NOVIQUE account", verificationEmailHtml(verifyLink));

  const accessToken = signAccessToken({ userId: user.id, role: user.role });
  const refreshToken = signRefreshToken({ userId: user.id });
  await prisma.refreshToken.create({
    data: { token: hashToken(refreshToken), userId: user.id, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
  });
  setRefreshCookie(res, refreshToken);

  res.status(201).json({
    accessToken,
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, emailVerified: user.emailVerified },
  });
}

export async function login(req: Request, res: Response) {
  const { email, password } = req.body;

  const user = await prisma.user.findUnique({ where: { email } });
  // Constant-shape error regardless of which field was wrong — avoids
  // leaking which emails exist on the platform (enumeration attack).
  if (!user || !user.passwordHash || !(await comparePassword(password, user.passwordHash))) {
    throw new ApiError(401, "Invalid email or password");
  }

  const accessToken = signAccessToken({ userId: user.id, role: user.role });
  const refreshToken = signRefreshToken({ userId: user.id });
  await prisma.refreshToken.create({
    data: { token: hashToken(refreshToken), userId: user.id, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
  });
  setRefreshCookie(res, refreshToken);

  res.json({
    accessToken,
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, emailVerified: user.emailVerified },
  });
}

export async function googleLogin(req: Request, res: Response) {
  const { idToken } = req.body as { idToken: string };
  if (!idToken) throw new ApiError(400, "idToken is required");

  const profile = await verifyGoogleIdToken(idToken);

  let user = await prisma.user.findUnique({ where: { googleId: profile.googleId } });
  if (!user) {
    user = await prisma.user.findUnique({ where: { email: profile.email } });
    user = user
      ? await prisma.user.update({ where: { id: user.id }, data: { googleId: profile.googleId, emailVerified: true } })
      : await prisma.user.create({
          data: { email: profile.email, fullName: profile.fullName, googleId: profile.googleId, emailVerified: true },
        });
  }

  const accessToken = signAccessToken({ userId: user.id, role: user.role });
  const refreshToken = signRefreshToken({ userId: user.id });
  await prisma.refreshToken.create({
    data: { token: hashToken(refreshToken), userId: user.id, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
  });
  setRefreshCookie(res, refreshToken);

  res.json({
    accessToken,
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, emailVerified: user.emailVerified },
  });
}

export async function verifyEmail(req: Request, res: Response) {
  const { token, uid } = req.body as { token: string; uid: string };
  const user = await prisma.user.findUnique({ where: { id: uid } });

  if (
    !user ||
    !user.emailVerifyTokenHash ||
    user.emailVerifyTokenHash !== hashToken(token) ||
    !user.emailVerifyExpires ||
    user.emailVerifyExpires < new Date()
  ) {
    throw new ApiError(400, "Verification link is invalid or has expired");
  }

  await prisma.user.update({
    where: { id: uid },
    data: { emailVerified: true, emailVerifyTokenHash: null, emailVerifyExpires: null },
  });

  res.json({ message: "Email verified successfully" });
}

export async function forgotPassword(req: Request, res: Response) {
  const { email } = req.body as { email: string };
  const user = await prisma.user.findUnique({ where: { email } });

  // Always respond 200 whether or not the account exists, to prevent
  // email enumeration through this endpoint.
  if (user) {
    const rawToken = crypto.randomBytes(32).toString("hex");
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordResetTokenHash: hashToken(rawToken), passwordResetExpires: new Date(Date.now() + 60 * 60 * 1000) },
    });
    const resetLink = `${env.clientUrl}/reset-password?token=${rawToken}&uid=${user.id}`;
    await sendEmail(email, "Reset your NOVIQUE password", passwordResetEmailHtml(resetLink));
  }

  res.json({ message: "If an account exists for that email, a reset link has been sent." });
}

export async function resetPassword(req: Request, res: Response) {
  const { token, uid, newPassword } = req.body as { token: string; uid: string; newPassword: string };

  if (!isPasswordStrongEnough(newPassword)) {
    throw new ApiError(400, "Password must be at least 8 characters and include a letter and a number");
  }

  const user = await prisma.user.findUnique({ where: { id: uid } });
  if (
    !user ||
    !user.passwordResetTokenHash ||
    user.passwordResetTokenHash !== hashToken(token) ||
    !user.passwordResetExpires ||
    user.passwordResetExpires < new Date()
  ) {
    throw new ApiError(400, "Reset link is invalid or has expired");
  }

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({
    where: { id: uid },
    data: { passwordHash, passwordResetTokenHash: null, passwordResetExpires: null },
  });

  // Invalidate all existing sessions on password change.
  await prisma.refreshToken.deleteMany({ where: { userId: uid } });

  res.json({ message: "Password reset successfully. Please log in again." });
}

export async function refresh(req: Request, res: Response) {
  const token = req.cookies?.[REFRESH_COOKIE];
  if (!token) throw new ApiError(401, "No refresh token provided");

  let payload: { userId: string };
  try {
    payload = verifyRefreshToken(token);
  } catch {
    throw new ApiError(401, "Invalid refresh token");
  }

  const stored = await prisma.refreshToken.findUnique({ where: { token: hashToken(token) } });
  if (!stored || stored.expiresAt < new Date()) {
    throw new ApiError(401, "Refresh token expired or revoked");
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user) throw new ApiError(401, "User no longer exists");

  const accessToken = signAccessToken({ userId: user.id, role: user.role });
  res.json({ accessToken });
}

export async function logout(req: Request, res: Response) {
  const token = req.cookies?.[REFRESH_COOKIE];
  if (token) {
    await prisma.refreshToken.deleteMany({ where: { token: hashToken(token) } });
  }
  res.clearCookie(REFRESH_COOKIE, { path: "/api/auth" });
  res.json({ message: "Logged out" });
}

export async function me(req: Request, res: Response) {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.userId },
    select: { id: true, email: true, fullName: true, role: true, emailVerified: true, styleProfile: true },
  });
  if (!user) throw new ApiError(404, "User not found");
  res.json({ user });
}
