import { Request, Response } from "express";
import prisma from "../config/db";

export async function listCategories(_req: Request, res: Response) {
  const categories = await prisma.category.findMany({ include: { children: true } , where: { parentId: null } });
  res.json({ categories });
}
