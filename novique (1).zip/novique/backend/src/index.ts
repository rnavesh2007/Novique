import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import hpp from "hpp";
import { env } from "./config/env";
import { apiLimiter } from "./middleware/rateLimiters";
import { errorMiddleware } from "./middleware/error.middleware";
import { asyncHandler } from "./utils/asyncHandler";
import { stripeWebhook } from "./controllers/payment.controller";

import authRoutes from "./routes/auth.routes";
import addressRoutes from "./routes/address.routes";
import productRoutes from "./routes/product.routes";
import categoryRoutes from "./routes/category.routes";
import cartRoutes from "./routes/cart.routes";
import wishlistRoutes from "./routes/wishlist.routes";
import orderRoutes from "./routes/order.routes";
import couponRoutes from "./routes/coupon.routes";
import reviewRoutes from "./routes/review.routes";
import paymentRoutes from "./routes/payment.routes";
import adminRoutes from "./routes/admin.routes";
import vendorRoutes from "./routes/vendor.routes";
import aiRoutes from "./routes/ai.routes";
import wardrobeRoutes from "./routes/wardrobe.routes";

const app = express();

// ---------- Security middleware (applied first, before any routing) ----------
app.use(helmet()); // sets sane security headers (CSP, X-Frame-Options, etc.)
app.use(
  cors({
    origin: env.clientUrl,
    credentials: true,
  })
);
app.use(hpp()); // strips duplicate/polluted query params, mitigates param-pollution attacks
app.use(cookieParser());

// Stripe webhook MUST be registered before express.json() and needs the raw
// body to verify the signature header — once express.json() runs, the
// stream is consumed and req.body becomes a parsed object instead of a Buffer.
app.post(
  "/api/payments/stripe/webhook",
  express.raw({ type: "application/json" }),
  asyncHandler(stripeWebhook)
);

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));

app.use(apiLimiter);

// ---------- Health check ----------
app.get("/health", (_req, res) => res.json({ status: "ok", service: "novique-api" }));

// ---------- Routes ----------
app.use("/api/auth", authRoutes);
app.use("/api/addresses", addressRoutes);
app.use("/api/products", productRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/wishlist", wishlistRoutes);
app.use("/api/wardrobe", wardrobeRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/coupons", couponRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/vendor", vendorRoutes);
app.use("/api/ai", aiRoutes);

// ---------- 404 + error handling ----------
app.use((req, res) => res.status(404).json({ error: "Not found" }));
app.use(errorMiddleware);

app.listen(env.port, () => {
  console.log(`NOVIQUE API listening on port ${env.port} [${env.nodeEnv}]`);
});

export default app;
