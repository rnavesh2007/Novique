import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || "587", 10),
  secure: false,
  auth: process.env.SMTP_USER
    ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    : undefined,
});

export async function sendEmail(to: string, subject: string, html: string) {
  if (!process.env.SMTP_HOST) {
    // No SMTP configured (e.g. local dev) — log instead of throwing, so the
    // signup/reset flow still completes end-to-end during development.
    console.log(`[email:dev] to=${to} subject="${subject}"\n${html}`);
    return;
  }
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || "NOVIQUE <no-reply@novique.example>",
    to,
    subject,
    html,
  });
}

export function verificationEmailHtml(link: string) {
  return `<div style="font-family:sans-serif;background:#000;color:#fff;padding:32px">
    <h1 style="color:#D4AF37;letter-spacing:2px">NOVIQUE</h1>
    <p>Style, Personalized by AI</p>
    <p>Confirm your email to activate your account:</p>
    <a href="${link}" style="display:inline-block;background:#D4AF37;color:#000;padding:12px 24px;text-decoration:none;border-radius:4px">Verify Email</a>
  </div>`;
}

export function passwordResetEmailHtml(link: string) {
  return `<div style="font-family:sans-serif;background:#000;color:#fff;padding:32px">
    <h1 style="color:#D4AF37;letter-spacing:2px">NOVIQUE</h1>
    <p>We received a request to reset your password.</p>
    <a href="${link}" style="display:inline-block;background:#D4AF37;color:#000;padding:12px 24px;text-decoration:none;border-radius:4px">Reset Password</a>
    <p style="opacity:0.6;font-size:12px">If you didn't request this, you can ignore this email.</p>
  </div>`;
}
