/**
 * NOVIQUE Recommendation Engine
 * ------------------------------
 * This is intentionally rule-based (not a black box) for the "Complete the
 * Look" / "Compatibility Score" / "Color Intelligence" features, so scores
 * are explainable and deterministic. The conversational stylist, occasion
 * copywriting, and review summarization layer on top via OpenAI
 * (see openai.service.ts) — but the underlying match math lives here.
 */

// ---------- Color theory ----------

export interface RGB { r: number; g: number; b: number }
export interface HSL { h: number; s: number; l: number }

export function hexToRgb(hex: string): RGB {
  const clean = hex.replace("#", "");
  const bigint = parseInt(clean.length === 3
    ? clean.split("").map((c) => c + c).join("")
    : clean, 16);
  return { r: (bigint >> 16) & 255, g: (bigint >> 8) & 255, b: bigint & 255 };
}

export function rgbToHsl({ r, g, b }: RGB): HSL {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  const d = max - min;
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1));
    switch (max) {
      case r: h = 60 * (((g - b) / d) % 6); break;
      case g: h = 60 * ((b - r) / d + 2); break;
      case b: h = 60 * ((r - g) / d + 4); break;
    }
  }
  if (h < 0) h += 360;
  return { h, s: s * 100, l: l * 100 };
}

export function hexToHsl(hex: string): HSL {
  return rgbToHsl(hexToRgb(hex));
}

function hueDistance(a: number, b: number): number {
  const diff = Math.abs(a - b) % 360;
  return diff > 180 ? 360 - diff : diff;
}

export type ColorRelationship =
  | "neutral-pair"     // black/white/grey/beige with anything — always safe
  | "monochrome"       // same hue family
  | "analogous"        // hues within ~30°
  | "complementary"    // hues ~150-210° apart
  | "triadic"          // hues ~100-140° apart
  | "clashing";         // everything else — saturated, far-apart hues

const NEUTRAL_LIGHTNESS_OR_SAT_THRESHOLD = 12; // very low saturation = neutral (greys/black/white)

function isNeutral(hsl: HSL): boolean {
  return hsl.s < NEUTRAL_LIGHTNESS_OR_SAT_THRESHOLD || hsl.l < 8 || hsl.l > 94;
}

export function classifyColorRelationship(hexA: string, hexB: string): ColorRelationship {
  const a = hexToHsl(hexA);
  const b = hexToHsl(hexB);
  if (isNeutral(a) || isNeutral(b)) return "neutral-pair";

  const dist = hueDistance(a.h, b.h);
  if (dist < 15) return "monochrome";
  if (dist < 40) return "analogous";
  if (dist >= 150 && dist <= 210) return "complementary";
  if (dist >= 100 && dist < 150) return "triadic";
  return "clashing";
}

const COLOR_SCORE_BY_RELATIONSHIP: Record<ColorRelationship, number> = {
  "neutral-pair": 95,
  monochrome: 88,
  analogous: 90,
  complementary: 92,
  triadic: 78,
  clashing: 45,
};

export function colorCompatibilityScore(hexA: string, hexB: string): { score: number; relationship: ColorRelationship } {
  const relationship = classifyColorRelationship(hexA, hexB);
  return { score: COLOR_SCORE_BY_RELATIONSHIP[relationship], relationship };
}

function explainRelationship(rel: ColorRelationship): string {
  switch (rel) {
    case "neutral-pair":
      return "one piece is a neutral tone, which pairs cleanly with almost any color";
    case "monochrome":
      return "both pieces share the same color family for a tonal, cohesive look";
    case "analogous":
      return "the colors sit close together on the color wheel, giving a harmonious, easy palette";
    case "complementary":
      return "the colors sit opposite each other on the color wheel, creating a deliberate, high-contrast pairing";
    case "triadic":
      return "the colors are moderately spaced on the wheel — works, but reads a bit busier";
    case "clashing":
      return "the colors are saturated and far apart on the wheel, which tends to fight for attention";
  }
}

// ---------- Garment compatibility ----------

// Which garment types are typically paired with which, for "Complete the Look".
// Keys/values are garmentType strings as stored on Product.garmentType.
const PAIRING_GRAPH: Record<string, string[]> = {
  shirt: ["jeans", "trousers", "chinos", "belt", "shoes", "sneakers", "watch", "jacket"],
  "t-shirt": ["jeans", "shorts", "sneakers", "jacket", "cap"],
  jeans: ["shirt", "t-shirt", "shoes", "sneakers", "belt", "jacket"],
  trousers: ["shirt", "shoes", "belt", "watch", "blazer"],
  dress: ["heels", "flats", "handbag", "earrings", "jacket"],
  blazer: ["shirt", "trousers", "shoes", "watch"],
  jacket: ["shirt", "t-shirt", "jeans", "sneakers"],
  shoes: ["shirt", "jeans", "trousers", "belt"],
  sneakers: ["jeans", "t-shirt", "jacket", "shorts"],
  belt: ["jeans", "trousers", "shirt"],
  watch: ["shirt", "trousers", "blazer"],
  sunglasses: ["t-shirt", "dress", "shorts"],
  handbag: ["dress", "heels"],
};

function garmentPairingScore(typeA: string, typeB: string): number {
  if (PAIRING_GRAPH[typeA]?.includes(typeB) || PAIRING_GRAPH[typeB]?.includes(typeA)) {
    return 100;
  }
  return 55; // not a typical pairing, but not forbidden — color can still carry it
}

export interface CompatibilityResult {
  score: number; // 0-100, weighted blend of garment pairing + color theory
  reason: string;
}

/**
 * Core "Compatibility Score" used by Complete-the-Look, e.g.
 *   White Shirt + Jeans = 96% Match
 * Weighting: garment-pairing convention (60%) + color theory (40%).
 */
export function computeCompatibility(
  a: { garmentType: string; primaryColor: string },
  b: { garmentType: string; primaryColor: string }
): CompatibilityResult {
  const pairingScore = garmentPairingScore(a.garmentType, b.garmentType);
  const { score: colorScore, relationship } = colorCompatibilityScore(a.primaryColor, b.primaryColor);

  const score = Math.round(pairingScore * 0.6 + colorScore * 0.4);
  const reason = `These are a conventional pairing for an outfit, and ${explainRelationship(relationship)}.`;

  return { score: Math.min(99, Math.max(30, score)), reason };
}

// ---------- Size recommendation ----------

export type BodyType = "SLIM" | "ATHLETIC" | "REGULAR" | "CURVY" | "PLUS_SIZE";

/**
 * Rough BMI + body-type heuristic mapped to a generic size label.
 * This is a starting point, not a substitute for brand-specific size charts —
 * in production you'd calibrate this per garment category using vendors'
 * actual measurement tables and store the mapping in the DB.
 */
export function recommendSize(heightCm: number, weightKg: number, bodyType?: BodyType): string {
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);

  let base: string;
  if (bmi < 18.5) base = "S";
  else if (bmi < 23) base = "M";
  else if (bmi < 27) base = "L";
  else if (bmi < 32) base = "XL";
  else base = "XXL";

  // Body type nudges the base size up/down one step for fit preference.
  const order = ["XS", "S", "M", "L", "XL", "XXL", "XXXL"];
  let idx = order.indexOf(base);
  if (bodyType === "ATHLETIC") idx += 1; // broader shoulders/chest typically size up
  if (bodyType === "SLIM") idx -= 1;
  if (bodyType === "PLUS_SIZE") idx += 1;
  idx = Math.min(order.length - 1, Math.max(0, idx));

  return order[idx];
}
