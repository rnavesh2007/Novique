import { OAuth2Client } from "google-auth-library";
import { env } from "../config/env";

const client = new OAuth2Client(env.google.clientId);

// Verifies the ID token the frontend gets from Google Identity Services
// (One Tap / OAuth popup). Never trust a client-supplied email/name without
// this server-side signature verification.
export async function verifyGoogleIdToken(idToken: string) {
  const ticket = await client.verifyIdToken({
    idToken,
    audience: env.google.clientId,
  });
  const payload = ticket.getPayload();
  if (!payload?.email) {
    throw new Error("Invalid Google token payload");
  }
  return {
    googleId: payload.sub,
    email: payload.email,
    fullName: payload.name || payload.email.split("@")[0],
  };
}
