/**
 * Tax & shipping calculation.
 * These are simple, transparent placeholder rules. In production, swap
 * calculateTax for a real tax API (TaxJar, Avalara, Stripe Tax) since sales
 * tax correctness is jurisdiction-specific and has real compliance stakes.
 * Swap calculateShipping for your carrier-rate API (Shippo, EasyPost) once
 * you have real package weights/dimensions and carrier accounts.
 */

const FLAT_TAX_RATE = 0.08; // 8% — replace with jurisdiction-aware lookup
const FREE_SHIPPING_THRESHOLD = 75;
const FLAT_SHIPPING_COST = 6.99;

export function calculateTax(subtotal: number): number {
  return Math.round(subtotal * FLAT_TAX_RATE * 100) / 100;
}

export function calculateShipping(subtotal: number): number {
  return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : FLAT_SHIPPING_COST;
}

export function applyDiscount(
  subtotal: number,
  coupon: { discountType: "PERCENTAGE" | "FIXED"; discountValue: number } | null
): number {
  if (!coupon) return 0;
  if (coupon.discountType === "PERCENTAGE") {
    return Math.round(subtotal * (coupon.discountValue / 100) * 100) / 100;
  }
  return Math.min(subtotal, coupon.discountValue);
}
