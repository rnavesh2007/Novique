import OpenAI from "openai";
import { env } from "../config/env";

const client = env.openai.apiKey ? new OpenAI({ apiKey: env.openai.apiKey }) : null;

function ensureClient(): OpenAI {
  if (!client) {
    throw new Error("OPENAI_API_KEY is not configured. Set it in your .env to enable AI features.");
  }
  return client;
}

const STYLIST_SYSTEM_PROMPT = `You are the NOVIQUE AI Personal Stylist — a knowledgeable, warm fashion
consultant for a premium fashion e-commerce platform. You give concrete,
practical styling advice (silhouettes, color pairing, fit, occasion-appropriateness).
Keep responses concise (3-6 sentences unless asked for more detail), and when
recommending specific garment types, use plain category names (e.g. "a tailored
blazer", "slim-fit chinos") rather than inventing brand names. Never claim to
be human. Never give medical, legal, or financial advice.`;

export async function personalShopperChat(history: { role: "user" | "assistant"; content: string }[]): Promise<string> {
  const openai = ensureClient();
  const completion = await openai.chat.completions.create({
    model: env.openai.model,
    messages: [{ role: "system", content: STYLIST_SYSTEM_PROMPT }, ...history],
    temperature: 0.7,
    max_tokens: 400,
  });
  return completion.choices[0]?.message?.content?.trim() || "";
}

export async function generateOccasionOutfitNarrative(params: {
  occasion: string;
  gender: string;
  items: { name: string; garmentType: string }[];
}): Promise<string> {
  const openai = ensureClient();
  const itemList = params.items.map((i) => `${i.garmentType}: ${i.name}`).join(", ");
  const completion = await openai.chat.completions.create({
    model: env.openai.model,
    messages: [
      { role: "system", content: STYLIST_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Write a short (2-3 sentence) styling note explaining why this outfit works for "${params.occasion}" (gender context: ${params.gender}). Items: ${itemList}.`,
      },
    ],
    temperature: 0.6,
    max_tokens: 150,
  });
  return completion.choices[0]?.message?.content?.trim() || "";
}

export async function summarizeReviews(reviews: string[]): Promise<string> {
  if (reviews.length === 0) return "";
  const openai = ensureClient();
  const completion = await openai.chat.completions.create({
    model: env.openai.model,
    messages: [
      {
        role: "system",
        content: "Summarize customer reviews for a fashion product into 2-3 neutral, factual sentences covering fit, quality, and any recurring praise or complaints. Do not invent details not present in the reviews.",
      },
      { role: "user", content: reviews.map((r, i) => `Review ${i + 1}: ${r}`).join("\n") },
    ],
    temperature: 0.3,
    max_tokens: 200,
  });
  return completion.choices[0]?.message?.content?.trim() || "";
}
