import bcrypt from "bcryptjs";

const SALT_ROUNDS = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

export async function comparePassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// Minimum bar: 8+ chars, at least one letter and one number.
// Tune to your threat model — consider zxcvbn for strength scoring in production.
export function isPasswordStrongEnough(plain: string): boolean {
  return /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(plain);
}
