import { Request, Response, NextFunction, RequestHandler } from "express";

// Wraps async route handlers so rejected promises reach Express's error
// middleware instead of crashing the process or hanging the request.
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>
): RequestHandler {
  return (req, res, next) => {
    fn(req, res, next).catch(next);
  };
}
