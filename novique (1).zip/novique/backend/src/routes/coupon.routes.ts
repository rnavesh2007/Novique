import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import * as ctrl from "../controllers/coupon.controller";

const router = Router();
router.post("/validate", asyncHandler(ctrl.validateCoupon));
router.post("/", requireAuth, requireRole("ADMIN"), validateBody(ctrl.createCouponSchema), asyncHandler(ctrl.createCoupon));
export default router;
