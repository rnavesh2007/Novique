import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/wardrobe.controller";

const router = Router();
router.use(requireAuth);
router.get("/", asyncHandler(ctrl.getWardrobe));
router.post("/", asyncHandler(ctrl.addToWardrobe));
router.get("/combinations", asyncHandler(ctrl.generateFromWardrobe));
router.delete("/:id", asyncHandler(ctrl.removeFromWardrobe));
export default router;
