import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { validateBody } from "../middleware/validate.middleware";
import { authLimiter } from "../middleware/rateLimiters";
import { requireAuth } from "../middleware/auth.middleware";
import * as auth from "../controllers/auth.controller";

const router = Router();

router.post("/signup", authLimiter, validateBody(auth.signupSchema), asyncHandler(auth.signup));
router.post("/login", authLimiter, validateBody(auth.loginSchema), asyncHandler(auth.login));
router.post("/google", authLimiter, asyncHandler(auth.googleLogin));
router.post("/verify-email", asyncHandler(auth.verifyEmail));
router.post("/forgot-password", authLimiter, asyncHandler(auth.forgotPassword));
router.post("/reset-password", authLimiter, asyncHandler(auth.resetPassword));
router.post("/refresh", asyncHandler(auth.refresh));
router.post("/logout", asyncHandler(auth.logout));
router.get("/me", requireAuth, asyncHandler(auth.me));

export default router;
