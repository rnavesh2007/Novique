import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import * as ctrl from "../controllers/review.controller";

const router = Router();
router.get("/product/:productId", asyncHandler(ctrl.listReviewsForProduct));
router.post("/", requireAuth, validateBody(ctrl.createReviewSchema), asyncHandler(ctrl.createReview));
export default router;
