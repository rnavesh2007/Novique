import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { validateBody } from "../middleware/validate.middleware";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/product.controller";

const router = Router();

router.get("/", asyncHandler(ctrl.listProducts));
router.get("/:slug", asyncHandler(ctrl.getProduct));
router.post(
  "/",
  requireAuth,
  requireRole("VENDOR", "ADMIN"),
  validateBody(ctrl.createProductSchema),
  asyncHandler(ctrl.createProduct)
);
router.patch("/:id", requireAuth, requireRole("VENDOR", "ADMIN"), asyncHandler(ctrl.updateProduct));
router.delete("/:id", requireAuth, requireRole("VENDOR", "ADMIN"), asyncHandler(ctrl.deleteProduct));

export default router;
