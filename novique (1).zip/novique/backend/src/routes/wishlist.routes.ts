import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/wishlist.controller";

const router = Router();
router.use(requireAuth);
router.get("/", asyncHandler(ctrl.getWishlist));
router.post("/", asyncHandler(ctrl.addToWishlist));
router.post("/:id/move-to-cart", asyncHandler(ctrl.moveToCart));
router.delete("/:id", asyncHandler(ctrl.removeFromWishlist));
export default router;
