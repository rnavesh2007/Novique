import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/admin.controller";

const router = Router();
router.use(requireAuth, requireRole("ADMIN"));

router.get("/stats", asyncHandler(ctrl.dashboardStats));
router.get("/users", asyncHandler(ctrl.listUsers));
router.get("/orders", asyncHandler(ctrl.listAllOrders));
router.patch("/orders/:id/status", asyncHandler(ctrl.updateOrderStatus));
router.get("/returns", asyncHandler(ctrl.listReturns));
router.patch("/vendors/:id/approve", asyncHandler(ctrl.approveVendor));

export default router;
