import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/payment.controller";

// NOTE: the Stripe webhook route is intentionally NOT here — it must receive
// the raw request body for signature verification, so it's mounted directly
// in index.ts with express.raw(), before the global express.json() middleware
// would otherwise consume the stream. See index.ts and payment.controller.ts.

const router = Router();
router.use(requireAuth);

router.post("/stripe/payment-intent", asyncHandler(ctrl.createStripePaymentIntent));
router.post("/stripe/refund", requireRole("ADMIN"), asyncHandler(ctrl.refundStripePayment));
router.post("/razorpay/order", asyncHandler(ctrl.createRazorpayOrder));
router.post("/paypal/order", asyncHandler(ctrl.createPaypalOrder));

export default router;
