import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import * as ctrl from "../controllers/vendor.controller";

const router = Router();
router.use(requireAuth);

router.post("/register", asyncHandler(ctrl.registerVendor));
router.get("/dashboard", requireRole("VENDOR", "ADMIN"), asyncHandler(ctrl.vendorDashboard));
router.get("/products", requireRole("VENDOR", "ADMIN"), asyncHandler(ctrl.vendorProducts));

export default router;
