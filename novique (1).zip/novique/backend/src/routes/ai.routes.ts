import { Router } from "express";
import multer from "multer";
import { asyncHandler } from "../utils/asyncHandler";
import { validateBody } from "../middleware/validate.middleware";
import { requireAuth } from "../middleware/auth.middleware";
import { aiLimiter } from "../middleware/rateLimiters";
import * as ai from "../controllers/ai.controller";

const router = Router();
const upload = multer({ limits: { fileSize: 8 * 1024 * 1024 } }); // 8MB cap for visual search uploads

router.post(
  "/style-profile",
  requireAuth,
  validateBody(ai.styleProfileSchema),
  asyncHandler(ai.saveStyleProfile)
);

router.get("/complete-the-look/:productId", aiLimiter, asyncHandler(ai.completeTheLook));

router.post(
  "/color-intelligence",
  aiLimiter,
  validateBody(ai.colorCheckSchema),
  asyncHandler(ai.colorIntelligence)
);

router.post(
  "/occasion-outfit",
  aiLimiter,
  validateBody(ai.occasionSchema),
  asyncHandler(ai.generateOccasionOutfit)
);

router.get("/trending", asyncHandler(ai.trending));

router.post("/chat", requireAuth, aiLimiter, validateBody(ai.chatSchema), asyncHandler(ai.chat));

router.post(
  "/size-recommendation",
  aiLimiter,
  validateBody(ai.sizeSchema),
  asyncHandler(ai.sizeRecommendation)
);

router.post("/visual-search", requireAuth, aiLimiter, upload.single("image"), asyncHandler(ai.visualSearch));

export default router;
