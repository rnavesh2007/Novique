import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import * as ctrl from "../controllers/order.controller";

const router = Router();
router.use(requireAuth);
router.post("/", validateBody(ctrl.placeOrderSchema), asyncHandler(ctrl.placeOrder));
router.get("/", asyncHandler(ctrl.listOrders));
router.get("/:id", asyncHandler(ctrl.getOrder));
router.post("/:id/cancel", asyncHandler(ctrl.cancelOrder));
router.post("/:id/return", validateBody(ctrl.returnRequestSchema), asyncHandler(ctrl.requestReturn));
export default router;
