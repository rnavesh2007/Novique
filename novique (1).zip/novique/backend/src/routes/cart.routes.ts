import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import * as ctrl from "../controllers/cart.controller";

const router = Router();
router.use(requireAuth);
router.get("/", asyncHandler(ctrl.getCart));
router.post("/", validateBody(ctrl.addToCartSchema), asyncHandler(ctrl.addToCart));
router.patch("/:id", asyncHandler(ctrl.updateCartItem));
router.delete("/:id", asyncHandler(ctrl.removeCartItem));
export default router;
