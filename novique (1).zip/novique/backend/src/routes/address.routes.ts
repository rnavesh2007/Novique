import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { requireAuth } from "../middleware/auth.middleware";
import { validateBody } from "../middleware/validate.middleware";
import * as ctrl from "../controllers/address.controller";

const router = Router();
router.use(requireAuth);
router.get("/", asyncHandler(ctrl.listAddresses));
router.post("/", validateBody(ctrl.addressSchema), asyncHandler(ctrl.createAddress));
router.delete("/:id", asyncHandler(ctrl.deleteAddress));
export default router;
