import { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";

// Generic request-body validator. Pass a Zod schema per route to reject
// malformed/unexpected input before it reaches a controller — this is also
// a key XSS/injection defense, since untyped junk never reaches the DB layer.
export function validateBody(schema: ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: "Validation failed", details: result.error.flatten() });
    }
    req.body = result.data;
    next();
  };
}
