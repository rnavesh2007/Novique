import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const men = await prisma.category.upsert({ where: { slug: "men" }, update: {}, create: { name: "Men", slug: "men" } });
  const women = await prisma.category.upsert({ where: { slug: "women" }, update: {}, create: { name: "Women", slug: "women" } });
  await prisma.category.upsert({ where: { slug: "kids" }, update: {}, create: { name: "Kids", slug: "kids" } });
  await prisma.category.upsert({ where: { slug: "accessories" }, update: {}, create: { name: "Accessories", slug: "accessories" } });
  await prisma.category.upsert({ where: { slug: "footwear" }, update: {}, create: { name: "Footwear", slug: "footwear" } });

  const products = [
    { name: "Classic White Oxford Shirt", slug: "classic-white-oxford-shirt", garmentType: "shirt", primaryColor: "#FFFFFF", basePrice: 59.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["office", "interview", "date-night"] },
    { name: "Slim Indigo Denim Jeans", slug: "slim-indigo-denim-jeans", garmentType: "jeans", primaryColor: "#2C3E66", basePrice: 79.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["casual", "travel", "college"] },
    { name: "Tailored Charcoal Trousers", slug: "tailored-charcoal-trousers", garmentType: "trousers", primaryColor: "#36454F", basePrice: 89.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["office", "interview", "wedding"] },
    { name: "Minimal Leather Sneakers", slug: "minimal-leather-sneakers", garmentType: "sneakers", primaryColor: "#FFFFFF", basePrice: 110.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["casual", "travel", "college"] },
    { name: "Black Derby Dress Shoes", slug: "black-derby-dress-shoes", garmentType: "shoes", primaryColor: "#000000", basePrice: 130.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["office", "interview", "wedding", "party"] },
    { name: "Brown Leather Belt", slug: "brown-leather-belt", garmentType: "belt", primaryColor: "#5C4033", basePrice: 35.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["office", "casual"] },
    { name: "Steel Chronograph Watch", slug: "steel-chronograph-watch", garmentType: "watch", primaryColor: "#C0C0C0", basePrice: 220.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["office", "wedding", "date-night"] },
    { name: "Navy Wool Blazer", slug: "navy-wool-blazer", garmentType: "blazer", primaryColor: "#1B2A4A", basePrice: 199.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["interview", "wedding", "party"] },
    { name: "Olive Bomber Jacket", slug: "olive-bomber-jacket", garmentType: "jacket", primaryColor: "#556B2F", basePrice: 149.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["travel", "casual"] },
    { name: "Heather Grey Crew T-Shirt", slug: "heather-grey-crew-tshirt", garmentType: "t-shirt", primaryColor: "#B0B0B0", basePrice: 29.0, gender: "MALE" as const, categoryId: men.id, occasionTags: ["casual", "festival", "college"] },
    { name: "Emerald Wrap Dress", slug: "emerald-wrap-dress", garmentType: "dress", primaryColor: "#046307", basePrice: 119.0, gender: "FEMALE" as const, categoryId: women.id, occasionTags: ["party", "date-night", "wedding"] },
    { name: "Nude Block Heels", slug: "nude-block-heels", garmentType: "heels", primaryColor: "#E3BC9A", basePrice: 95.0, gender: "FEMALE" as const, categoryId: women.id, occasionTags: ["party", "wedding", "date-night"] },
    { name: "Gold Drop Earrings", slug: "gold-drop-earrings", garmentType: "earrings", primaryColor: "#D4AF37", basePrice: 45.0, gender: "FEMALE" as const, categoryId: women.id, occasionTags: ["party", "wedding"] },
    { name: "Tan Structured Handbag", slug: "tan-structured-handbag", garmentType: "handbag", primaryColor: "#C19A6B", basePrice: 175.0, gender: "FEMALE" as const, categoryId: women.id, occasionTags: ["office", "date-night"] },
    { name: "Black Aviator Sunglasses", slug: "black-aviator-sunglasses", garmentType: "sunglasses", primaryColor: "#000000", basePrice: 65.0, gender: "UNISEX" as const, categoryId: men.id, occasionTags: ["festival", "casual", "travel"] },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {},
      create: {
        name: p.name,
        slug: p.slug,
        description: `${p.name} — part of the NOVIQUE curated collection.`,
        categoryId: p.categoryId,
        gender: p.gender,
        basePrice: p.basePrice,
        primaryColor: p.primaryColor,
        garmentType: p.garmentType,
        occasionTags: p.occasionTags,
        images: [],
        trendScore: Math.random() * 100,
        variants: {
          create: [
            { size: "S", color: p.primaryColor, sku: `${p.slug}-S`, stock: 20 },
            { size: "M", color: p.primaryColor, sku: `${p.slug}-M`, stock: 30 },
            { size: "L", color: p.primaryColor, sku: `${p.slug}-L`, stock: 25 },
          ],
        },
      },
    });
  }

  await prisma.coupon.upsert({
    where: { code: "NOVIQUE10" },
    update: {},
    create: { code: "NOVIQUE10", discountType: "PERCENTAGE", discountValue: 10, minOrderValue: 50 },
  });

  console.log(`Seeded ${products.length} products across ${2} categories, plus a welcome coupon (NOVIQUE10).`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
