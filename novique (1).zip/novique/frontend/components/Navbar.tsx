import Link from "next/link";
import { Search, Heart, ShoppingBag, Sparkles, User } from "lucide-react";

const NAV_LINKS = [
  { href: "/products?gender=MALE", label: "Men" },
  { href: "/products?gender=FEMALE", label: "Women" },
  { href: "/products?gender=KIDS", label: "Kids" },
  { href: "/products?category=accessories", label: "Accessories" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-paper/95 backdrop-blur border-b border-black/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          <Link href="/" className="flex flex-col items-start group">
            <span className="font-display text-3xl tracking-wider2 leading-none">NOVIQUE</span>
            <span className="label-tracked text-gold mt-1">Style, Personalized by AI</span>
          </Link>

          <nav className="hidden md:flex items-center gap-10 label-tracked">
            {NAV_LINKS.map((link) => (
              <Link key={link.href} href={link.href} className="hover:text-gold transition-colors focus-ring">
                {link.label}
              </Link>
            ))}
            <Link href="/stylist/chat" className="flex items-center gap-1.5 hover:text-gold transition-colors focus-ring">
              <Sparkles size={14} /> AI Stylist
            </Link>
          </nav>

          <div className="flex items-center gap-5">
            <button aria-label="Search" className="focus-ring"><Search size={20} /></button>
            <Link href="/wishlist" aria-label="Wishlist" className="focus-ring"><Heart size={20} /></Link>
            <Link href="/cart" aria-label="Cart" className="focus-ring"><ShoppingBag size={20} /></Link>
            <Link href="/login" aria-label="Account" className="focus-ring"><User size={20} /></Link>
          </div>
        </div>
      </div>
      <div className="hairline-gold" />
    </header>
  );
}
