import Link from "next/link";
import { Heart } from "lucide-react";

interface Product {
  id: string;
  name: string;
  slug: string;
  basePrice: number | string;
  discountPrice?: number | string | null;
  primaryColor: string;
  images: string[];
}

export default function ProductCard({ product }: { product: Product }) {
  const price = product.discountPrice ?? product.basePrice;
  return (
    <Link href={`/products/${product.slug}`} className="group block focus-ring">
      <div
        className="aspect-[3/4] bg-mist mb-3 relative overflow-hidden"
        style={{ backgroundColor: product.images[0] ? undefined : `${product.primaryColor}15` }}
      >
        {product.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-xs text-ink/30 label-tracked">No image</div>
        )}
        <button
          aria-label="Add to wishlist"
          className="absolute top-3 right-3 bg-paper/90 rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity focus-ring"
        >
          <Heart size={16} />
        </button>
      </div>
      <p className="text-sm">{product.name}</p>
      <p className="text-sm text-gold mt-1">${Number(price).toFixed(2)}</p>
    </Link>
  );
}
