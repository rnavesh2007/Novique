"use client";
import { useState } from "react";
import { api } from "@/lib/api";

interface Variant {
  id: string;
  size: string;
  color: string;
  stock: number;
}

export default function AddToCartForm({ productId, variants }: { productId: string; variants: Variant[] }) {
  const sizes = Array.from(new Set(variants.map((v) => v.size)));
  const [selectedSize, setSelectedSize] = useState(sizes[0]);
  const [status, setStatus] = useState<"idle" | "loading" | "added" | "error">("idle");

  const variant = variants.find((v) => v.size === selectedSize);

  async function handleAddToCart() {
    if (!variant) return;
    setStatus("loading");
    try {
      await api("/cart", { method: "POST", body: JSON.stringify({ productId, variantId: variant.id, quantity: 1 }) });
      setStatus("added");
    } catch {
      setStatus("error");
    }
  }

  return (
    <div>
      <p className="label-tracked text-xs mb-2">Size</p>
      <div className="flex gap-2 mb-6">
        {sizes.map((size) => (
          <button
            key={size}
            onClick={() => setSelectedSize(size)}
            className={`w-12 h-12 border text-sm focus-ring ${
              selectedSize === size ? "border-gold text-gold" : "border-ink/20"
            }`}
          >
            {size}
          </button>
        ))}
      </div>

      <button
        onClick={handleAddToCart}
        disabled={status === "loading" || !variant || variant.stock === 0}
        className="w-full bg-ink text-paper py-4 label-tracked disabled:opacity-40 focus-ring"
      >
        {status === "added" ? "Added to Cart" : status === "loading" ? "Adding…" : "Add to Cart"}
      </button>
      {status === "error" && (
        <p className="text-sm text-red-600 mt-2">Couldn't add to cart — please sign in first.</p>
      )}
    </div>
  );
}
