import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-ink text-paper mt-24">
      <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-2 md:grid-cols-4 gap-10">
        <div>
          <p className="font-display text-2xl tracking-wider2">NOVIQUE</p>
          <p className="label-tracked text-gold mt-2">Style, Personalized by AI</p>
        </div>
        <div>
          <p className="label-tracked text-gold mb-3">Shop</p>
          <ul className="space-y-2 text-sm text-paper/80">
            <li><Link href="/products?gender=MALE">Men</Link></li>
            <li><Link href="/products?gender=FEMALE">Women</Link></li>
            <li><Link href="/products?gender=KIDS">Kids</Link></li>
          </ul>
        </div>
        <div>
          <p className="label-tracked text-gold mb-3">AI Stylist</p>
          <ul className="space-y-2 text-sm text-paper/80">
            <li><Link href="/profile/style-quiz">Style Quiz</Link></li>
            <li><Link href="/stylist/chat">Personal Shopper</Link></li>
          </ul>
        </div>
        <div>
          <p className="label-tracked text-gold mb-3">Account</p>
          <ul className="space-y-2 text-sm text-paper/80">
            <li><Link href="/orders">Track Order</Link></li>
            <li><Link href="/vendor/dashboard">Sell on NOVIQUE</Link></li>
          </ul>
        </div>
      </div>
      <div className="hairline-gold" />
      <p className="text-center text-xs text-paper/40 py-6">© {new Date().getFullYear()} NOVIQUE. All rights reserved.</p>
    </footer>
  );
}
