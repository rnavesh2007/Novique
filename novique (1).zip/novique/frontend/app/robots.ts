import { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://novique.example";
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/vendor", "/checkout", "/cart"] }],
    sitemap: `${base}/sitemap.xml`,
  };
}
