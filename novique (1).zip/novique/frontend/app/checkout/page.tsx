"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";

interface Address {
  id: string;
  label: string;
  line1: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

const emptyForm = { label: "Home", line1: "", city: "", state: "", postalCode: "", country: "", phone: "" };

export default function CheckoutPage() {
  const router = useRouter();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<string>("");
  const [couponCode, setCouponCode] = useState("");
  const [status, setStatus] = useState<"idle" | "placing" | "error">("idle");
  const [error, setError] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    api<{ addresses: Address[] }>("/addresses")
      .then((d) => {
        setAddresses(d.addresses);
        if (d.addresses[0]) setSelectedAddress(d.addresses[0].id);
        setShowAddForm(d.addresses.length === 0);
      })
      .catch(() => router.push("/login?next=/checkout"));
  }, [router]);

  async function addAddress() {
    const { address } = await api<{ address: Address }>("/addresses", {
      method: "POST",
      body: JSON.stringify({ ...form, isDefault: addresses.length === 0 }),
    });
    setAddresses((prev) => [...prev, address]);
    setSelectedAddress(address.id);
    setShowAddForm(false);
    setForm(emptyForm);
  }

  async function placeOrder() {
    if (!selectedAddress) {
      setError("Please select or add a delivery address.");
      return;
    }
    setStatus("placing");
    try {
      const { order } = await api<{ order: any }>("/orders", {
        method: "POST",
        body: JSON.stringify({ addressId: selectedAddress, couponCode: couponCode || undefined }),
      });
      // Creates the Stripe PaymentIntent server-side; in a full build this
      // clientSecret feeds a Stripe Elements <PaymentElement> on the next
      // screen to collect card details and confirm payment client-side.
      await api("/payments/stripe/payment-intent", { method: "POST", body: JSON.stringify({ orderId: order.id }) });
      router.push(`/orders/${order.id}`);
    } catch (e: any) {
      setError(e.message || "Could not place order");
      setStatus("error");
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-12">
      <h1 className="font-display text-4xl mb-10">Checkout</h1>

      <section className="mb-10">
        <div className="flex items-baseline justify-between mb-4">
          <p className="label-tracked text-gold">Delivery Address</p>
          <button onClick={() => setShowAddForm((s) => !s)} className="text-sm hover:text-gold focus-ring">
            + Add new
          </button>
        </div>

        {addresses.length > 0 && (
          <div className="space-y-3 mb-4">
            {addresses.map((a) => (
              <label key={a.id} className="flex items-start gap-3 border border-ink/15 p-4 cursor-pointer">
                <input type="radio" name="address" checked={selectedAddress === a.id} onChange={() => setSelectedAddress(a.id)} />
                <span className="text-sm">{a.line1}, {a.city}, {a.state} {a.postalCode}, {a.country}</span>
              </label>
            ))}
          </div>
        )}

        {showAddForm && (
          <div className="border border-ink/15 p-4 space-y-3">
            {(["line1", "city", "state", "postalCode", "country", "phone"] as const).map((field) => (
              <input
                key={field}
                placeholder={field}
                value={form[field]}
                onChange={(e) => setForm((f) => ({ ...f, [field]: e.target.value }))}
                className="w-full border border-ink/20 px-3 py-2 text-sm focus-ring"
              />
            ))}
            <button onClick={addAddress} className="bg-ink text-paper px-5 py-2 text-sm label-tracked focus-ring">
              Save Address
            </button>
          </div>
        )}
      </section>

      <section className="mb-10">
        <p className="label-tracked text-gold mb-4">Coupon Code</p>
        <input
          value={couponCode}
          onChange={(e) => setCouponCode(e.target.value)}
          placeholder="e.g. NOVIQUE10"
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
      </section>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <button
        onClick={placeOrder}
        disabled={status === "placing"}
        className="w-full bg-ink text-paper py-4 label-tracked disabled:opacity-40 focus-ring"
      >
        {status === "placing" ? "Placing order…" : "Place Order"}
      </button>
    </div>
  );
}

