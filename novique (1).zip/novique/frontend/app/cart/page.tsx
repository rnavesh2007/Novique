"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";

interface CartItem {
  id: string;
  quantity: number;
  product: { name: string; basePrice: number; discountPrice?: number; primaryColor: string; images: string[] };
  variant: { size: string; color: string };
}

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api<{ items: CartItem[] }>("/cart")
      .then((d) => setItems(d.items))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  async function updateQuantity(id: string, quantity: number) {
    await api(`/cart/${id}`, { method: "PATCH", body: JSON.stringify({ quantity }) });
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, quantity } : i)));
  }

  async function removeItem(id: string) {
    await api(`/cart/${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  const subtotal = items.reduce((sum, i) => sum + Number(i.product.discountPrice ?? i.product.basePrice) * i.quantity, 0);

  if (loading) return <div className="max-w-4xl mx-auto px-6 py-20 text-center text-ink/50">Loading cart…</div>;

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <h1 className="font-display text-4xl mb-10">Your Cart</h1>

      {items.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-ink/60 mb-6">Your cart is empty.</p>
          <Link href="/products" className="bg-ink text-paper px-8 py-3 label-tracked focus-ring">Browse Products</Link>
        </div>
      ) : (
        <>
          <div className="divide-y divide-ink/10">
            {items.map((item) => (
              <div key={item.id} className="flex items-center gap-6 py-6">
                <div className="w-24 h-32 bg-mist flex-shrink-0" style={{ backgroundColor: `${item.product.primaryColor}15` }} />
                <div className="flex-1">
                  <p>{item.product.name}</p>
                  <p className="text-sm text-ink/50">{item.variant.size} / {item.variant.color}</p>
                  <p className="text-gold mt-1">${Number(item.product.discountPrice ?? item.product.basePrice).toFixed(2)}</p>
                </div>
                <input
                  type="number"
                  min={1}
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.id, parseInt(e.target.value, 10) || 1)}
                  className="w-16 border border-ink/20 text-center py-2 focus-ring"
                />
                <button onClick={() => removeItem(item.id)} className="text-sm text-ink/50 hover:text-ink focus-ring">
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center mt-10 pt-6 border-t border-ink/10">
            <span className="label-tracked">Subtotal</span>
            <span className="text-xl text-gold">${subtotal.toFixed(2)}</span>
          </div>
          <Link href="/checkout" className="block text-center bg-ink text-paper py-4 mt-6 label-tracked focus-ring">
            Proceed to Checkout
          </Link>
        </>
      )}
    </div>
  );
}
