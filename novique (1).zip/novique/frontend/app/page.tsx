import Link from "next/link";
import { api } from "@/lib/api";
import ProductCard from "@/components/ProductCard";

async function getTrending() {
  try {
    const data = await api<{ trendingNow: any[] }>("/ai/trending");
    return data.trendingNow;
  } catch {
    return [];
  }
}

const OCCASIONS = ["Office", "Interview", "Wedding", "Casual", "Travel", "Date Night", "Festival", "Party"];

export default async function HomePage() {
  const trending = await getTrending();

  return (
    <div>
      {/* Hero — the thesis: an AI that builds you a finished outfit, not a product grid */}
      <section className="max-w-7xl mx-auto px-6 pt-20 pb-16 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <p className="label-tracked text-gold mb-4">AI Personal Stylist</p>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05]">
            Don't shop for clothes.
            <br />
            Shop for outfits.
          </h1>
          <p className="mt-6 text-ink/70 max-w-md">
            Tell NOVIQUE your size, your budget, your occasion. Our AI scores every
            pairing and builds the complete look — shirt to shoes — before you buy a thing.
          </p>
          <div className="mt-8 flex gap-4">
            <Link href="/profile/style-quiz" className="bg-ink text-paper px-8 py-3 label-tracked focus-ring">
              Take the Style Quiz
            </Link>
            <Link href="/stylist/chat" className="border border-ink px-8 py-3 label-tracked focus-ring">
              Chat with the Stylist
            </Link>
          </div>
        </div>
        <div className="hairline-gold md:rotate-90 md:h-px md:w-full" />
      </section>

      {/* Occasion generator entry points */}
      <section className="max-w-7xl mx-auto px-6 pb-16">
        <p className="label-tracked text-gold mb-4">Shop by Occasion</p>
        <div className="flex flex-wrap gap-3">
          {OCCASIONS.map((o) => (
            <Link
              key={o}
              href={`/products?occasion=${o.toLowerCase().replace(" ", "-")}`}
              className="border border-ink/15 px-5 py-2 text-sm hover:border-gold hover:text-gold transition-colors focus-ring"
            >
              {o}
            </Link>
          ))}
        </div>
      </section>

      {trending.length > 0 && (
        <section className="max-w-7xl mx-auto px-6 pb-24">
          <div className="flex items-baseline justify-between mb-6">
            <h2 className="font-display text-3xl">Trending Now</h2>
            <Link href="/products" className="label-tracked text-sm hover:text-gold focus-ring">View all</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {trending.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
