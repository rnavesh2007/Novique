"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";

interface WishlistItem {
  id: string;
  product: { id: string; name: string; slug: string; basePrice: number; primaryColor: string; images: string[] };
}

export default function WishlistPage() {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api<{ items: WishlistItem[] }>("/wishlist")
      .then((d) => setItems(d.items))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  async function remove(id: string) {
    await api(`/wishlist/${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  if (loading) return <div className="max-w-5xl mx-auto px-6 py-20 text-center text-ink/50">Loading wishlist…</div>;

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <h1 className="font-display text-4xl mb-10">Your Wishlist</h1>

      {items.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-ink/60 mb-6">Nothing saved yet.</p>
          <Link href="/products" className="bg-ink text-paper px-8 py-3 label-tracked focus-ring">Browse Products</Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {items.map((item) => (
            <div key={item.id}>
              <Link href={`/products/${item.product.slug}`}>
                <div className="aspect-[3/4] bg-mist mb-3" style={{ backgroundColor: `${item.product.primaryColor}15` }} />
                <p className="text-sm">{item.product.name}</p>
                <p className="text-sm text-gold">${Number(item.product.basePrice).toFixed(2)}</p>
              </Link>
              <button onClick={() => remove(item.id)} className="text-xs text-ink/50 hover:text-ink mt-2 focus-ring">
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
