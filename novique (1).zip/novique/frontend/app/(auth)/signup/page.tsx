"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, setAccessToken } from "@/lib/api";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { accessToken } = await api<{ accessToken: string }>("/auth/signup", {
        method: "POST",
        body: JSON.stringify({ fullName, email, password }),
        skipAuth: true,
      });
      setAccessToken(accessToken);
      router.push("/profile/style-quiz");
    } catch (e: any) {
      setError(e.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <h1 className="font-display text-4xl mb-2">Join NOVIQUE</h1>
      <p className="text-ink/60 mb-10">Create your account to start building outfits with AI.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          required
          placeholder="Full name"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
        <input
          type="email"
          required
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
        <input
          type="password"
          required
          placeholder="Password (8+ characters)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={loading} className="w-full bg-ink text-paper py-4 label-tracked disabled:opacity-40 focus-ring">
          {loading ? "Creating account…" : "Create Account"}
        </button>
      </form>

      <p className="text-sm text-ink/60 mt-8 text-center">
        Already have an account? <Link href="/login" className="text-gold">Sign in</Link>
      </p>
    </div>
  );
}
