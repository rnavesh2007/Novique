"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, setAccessToken } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { accessToken } = await api<{ accessToken: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
        skipAuth: true,
      });
      setAccessToken(accessToken);
      router.push("/");
    } catch (e: any) {
      setError(e.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <h1 className="font-display text-4xl mb-2">Welcome Back</h1>
      <p className="text-ink/60 mb-10">Sign in to your NOVIQUE account.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          required
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
        <input
          type="password"
          required
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-ink/20 px-4 py-3 focus-ring"
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={loading} className="w-full bg-ink text-paper py-4 label-tracked disabled:opacity-40 focus-ring">
          {loading ? "Signing in…" : "Sign In"}
        </button>
      </form>

      <div className="flex items-center gap-3 my-6">
        <div className="hairline-gold flex-1" />
        <span className="text-xs text-ink/40">or</span>
        <div className="hairline-gold flex-1" />
      </div>

      {/* Wire this button to Google Identity Services' renderButton/One Tap,
         then POST the returned credential as { idToken } to /auth/google. */}
      <button className="w-full border border-ink/20 py-4 label-tracked focus-ring">
        Continue with Google
      </button>

      <p className="text-sm text-ink/60 mt-8 text-center">
        <Link href="/forgot-password" className="hover:text-gold">Forgot password?</Link>
      </p>
      <p className="text-sm text-ink/60 mt-2 text-center">
        New here? <Link href="/signup" className="text-gold">Create an account</Link>
      </p>
    </div>
  );
}
