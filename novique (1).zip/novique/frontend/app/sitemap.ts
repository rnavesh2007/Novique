import { MetadataRoute } from "next";

// Dynamic sitemap — in production, extend this to fetch all active product
// slugs from the API and include one <url> entry per product/category.
export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://novique.example";
  const staticRoutes = ["", "/products", "/stylist/chat", "/profile/style-quiz", "/login", "/signup"];
  return staticRoutes.map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: "daily" as const,
    priority: route === "" ? 1 : 0.7,
  }));
}
