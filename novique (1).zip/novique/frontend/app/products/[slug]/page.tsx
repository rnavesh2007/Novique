import { api } from "@/lib/api";
import CompatibilityBadge from "@/components/CompatibilityBadge";
import Link from "next/link";
import AddToCartForm from "@/components/AddToCartForm";

async function getProduct(slug: string) {
  const data = await api<{ product: any }>(`/products/${slug}`, { skipAuth: true });
  return data.product;
}

async function getCompleteTheLook(productId: string) {
  try {
    const data = await api<{ completeTheLook: any[] }>(`/ai/complete-the-look/${productId}?limit=6`, { skipAuth: true });
    return data.completeTheLook;
  } catch {
    return [];
  }
}

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = await getProduct(params.slug);
  const completeTheLook = await getCompleteTheLook(product.id);
  const price = product.discountPrice ?? product.basePrice;

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="grid md:grid-cols-2 gap-12">
        {/* Image */}
        <div className="aspect-[3/4] bg-mist" style={{ backgroundColor: `${product.primaryColor}15` }}>
          {product.images?.[0] && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
          )}
        </div>

        {/* Details */}
        <div>
          <p className="label-tracked text-gold mb-2">{product.category?.name}</p>
          <h1 className="font-display text-4xl mb-3">{product.name}</h1>
          <p className="text-2xl text-gold mb-6">${Number(price).toFixed(2)}</p>
          <p className="text-ink/70 leading-relaxed mb-8">{product.description}</p>

          <AddToCartForm productId={product.id} variants={product.variants} />

          {product.reviews?.length > 0 && (
            <div className="mt-10 pt-10 border-t border-ink/10">
              <p className="label-tracked text-gold mb-4">Reviews</p>
              {product.reviews[0].aiSummary && (
                <p className="text-sm bg-mist p-4 mb-4 italic">"{product.reviews[0].aiSummary}"</p>
              )}
              {product.reviews.map((r: any) => (
                <div key={r.id} className="mb-4 text-sm">
                  <p className="font-medium">{r.user.fullName} — {r.rating}/5</p>
                  <p className="text-ink/70">{r.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Complete the Look — the signature AI feature */}
      {completeTheLook.length > 0 && (
        <section className="mt-20 pt-12 border-t border-ink/10">
          <p className="label-tracked text-gold mb-2">AI Outfit Recommendation</p>
          <h2 className="font-display text-3xl mb-8">Complete the Look</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            {completeTheLook.map((item) => (
              <Link key={item.product.id} href={`/products/${item.product.slug}`} className="group focus-ring">
                <div className="aspect-[3/4] bg-mist mb-3 relative" style={{ backgroundColor: `${item.product.primaryColor}15` }}>
                  <div className="absolute bottom-3 right-3 bg-paper rounded-full shadow-sm">
                    <CompatibilityBadge score={item.score} />
                  </div>
                </div>
                <p className="text-sm">{item.product.name}</p>
                <p className="text-xs text-ink/50 mt-1">{item.reason}</p>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
