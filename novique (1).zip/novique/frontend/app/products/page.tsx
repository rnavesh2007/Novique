import { api } from "@/lib/api";
import ProductCard from "@/components/ProductCard";

interface SearchParams {
  gender?: string;
  category?: string;
  occasion?: string;
  q?: string;
}

async function getProducts(params: SearchParams) {
  const query = new URLSearchParams();
  if (params.gender) query.set("gender", params.gender);
  if (params.category) query.set("category", params.category);
  if (params.q) query.set("q", params.q);
  try {
    return await api<{ items: any[]; total: number }>(`/products?${query.toString()}`, { skipAuth: true });
  } catch {
    return { items: [], total: 0 };
  }
}

export default async function ProductsPage({ searchParams }: { searchParams: SearchParams }) {
  const { items, total } = await getProducts(searchParams);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <p className="label-tracked text-gold mb-2">Catalog</p>
      <h1 className="font-display text-4xl mb-2">
        {searchParams.gender ? `${searchParams.gender.charAt(0)}${searchParams.gender.slice(1).toLowerCase()}'s Edit` : "All Products"}
      </h1>
      <p className="text-sm text-ink/50 mb-10">{total} pieces</p>

      {items.length === 0 ? (
        <p className="text-ink/60">
          No products match yet — run the seed script (<code>npm run seed</code> in /backend) to populate the catalog.
        </p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
