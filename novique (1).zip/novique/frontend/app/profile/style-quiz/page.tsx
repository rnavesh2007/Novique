"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";

const STYLE_OPTIONS = ["Minimalist", "Streetwear", "Formal", "Bohemian", "Athleisure", "Vintage"];
const OCCASION_OPTIONS = ["Office", "Casual", "Travel", "Party", "Wedding", "Date Night"];

export default function StyleQuizPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    gender: "UNISEX",
    age: 28,
    heightCm: 170,
    weightKg: 70,
    bodyType: "REGULAR",
    favoriteColors: [] as string[],
    preferredStyles: [] as string[],
    budgetMin: 30,
    budgetMax: 200,
    occasionFocus: [] as string[],
  });
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ recommendedSize?: string } | null>(null);

  function toggle(field: "preferredStyles" | "occasionFocus", value: string) {
    setForm((f) => ({
      ...f,
      [field]: f[field].includes(value) ? f[field].filter((v) => v !== value) : [...f[field], value],
    }));
  }

  async function submit() {
    setSubmitting(true);
    try {
      const { profile } = await api<{ profile: any }>("/ai/style-profile", { method: "POST", body: JSON.stringify(form) });
      setResult(profile);
    } finally {
      setSubmitting(false);
    }
  }

  const steps = [
    // Step 0 — basics
    <div key="basics" className="space-y-6">
      <div>
        <p className="label-tracked text-gold mb-3">Gender</p>
        <div className="flex gap-3">
          {["MALE", "FEMALE", "UNISEX", "KIDS"].map((g) => (
            <button
              key={g}
              onClick={() => setForm((f) => ({ ...f, gender: g }))}
              className={`px-5 py-2 border text-sm focus-ring ${form.gender === g ? "border-gold text-gold" : "border-ink/20"}`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <label className="block">
          <span className="text-sm text-ink/60">Age</span>
          <input type="number" value={form.age} onChange={(e) => setForm((f) => ({ ...f, age: +e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring" />
        </label>
        <label className="block">
          <span className="text-sm text-ink/60">Body type</span>
          <select value={form.bodyType} onChange={(e) => setForm((f) => ({ ...f, bodyType: e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring">
            {["SLIM", "ATHLETIC", "REGULAR", "CURVY", "PLUS_SIZE"].map((b) => <option key={b}>{b}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="text-sm text-ink/60">Height (cm)</span>
          <input type="number" value={form.heightCm} onChange={(e) => setForm((f) => ({ ...f, heightCm: +e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring" />
        </label>
        <label className="block">
          <span className="text-sm text-ink/60">Weight (kg)</span>
          <input type="number" value={form.weightKg} onChange={(e) => setForm((f) => ({ ...f, weightKg: +e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring" />
        </label>
      </div>
    </div>,

    // Step 1 — style + occasion
    <div key="style" className="space-y-8">
      <div>
        <p className="label-tracked text-gold mb-3">Fashion Preferences</p>
        <div className="flex flex-wrap gap-2">
          {STYLE_OPTIONS.map((s) => (
            <button key={s} onClick={() => toggle("preferredStyles", s)} className={`px-4 py-2 border text-sm focus-ring ${form.preferredStyles.includes(s) ? "border-gold text-gold" : "border-ink/20"}`}>
              {s}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="label-tracked text-gold mb-3">Occasions You Shop For</p>
        <div className="flex flex-wrap gap-2">
          {OCCASION_OPTIONS.map((o) => (
            <button key={o} onClick={() => toggle("occasionFocus", o)} className={`px-4 py-2 border text-sm focus-ring ${form.occasionFocus.includes(o) ? "border-gold text-gold" : "border-ink/20"}`}>
              {o}
            </button>
          ))}
        </div>
      </div>
    </div>,

    // Step 2 — budget
    <div key="budget" className="space-y-4">
      <p className="label-tracked text-gold mb-3">Budget Range (per item, USD)</p>
      <div className="flex gap-4">
        <label className="block flex-1">
          <span className="text-sm text-ink/60">Min</span>
          <input type="number" value={form.budgetMin} onChange={(e) => setForm((f) => ({ ...f, budgetMin: +e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring" />
        </label>
        <label className="block flex-1">
          <span className="text-sm text-ink/60">Max</span>
          <input type="number" value={form.budgetMax} onChange={(e) => setForm((f) => ({ ...f, budgetMax: +e.target.value }))} className="w-full border border-ink/20 px-3 py-2 mt-1 focus-ring" />
        </label>
      </div>
    </div>,
  ];

  if (result) {
    return (
      <div className="max-w-md mx-auto px-6 py-24 text-center">
        <p className="label-tracked text-gold mb-3">Profile Saved</p>
        <h1 className="font-display text-3xl mb-4">You're all set.</h1>
        {result.recommendedSize && (
          <p className="text-ink/70 mb-8">Your AI-recommended size is <span className="text-gold">{result.recommendedSize}</span>.</p>
        )}
        <button onClick={() => router.push("/products")} className="bg-ink text-paper px-8 py-3 label-tracked focus-ring">
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-6 py-16">
      <p className="label-tracked text-gold mb-2">AI Fashion Stylist</p>
      <h1 className="font-display text-4xl mb-10">Tell us about yourself</h1>

      {steps[step]}

      <div className="flex justify-between mt-12">
        <button
          onClick={() => setStep((s) => Math.max(0, s - 1))}
          disabled={step === 0}
          className="text-sm disabled:opacity-30 focus-ring"
        >
          ← Back
        </button>
        {step < steps.length - 1 ? (
          <button onClick={() => setStep((s) => s + 1)} className="bg-ink text-paper px-8 py-3 label-tracked focus-ring">
            Continue
          </button>
        ) : (
          <button onClick={submit} disabled={submitting} className="bg-ink text-paper px-8 py-3 label-tracked disabled:opacity-40 focus-ring">
            {submitting ? "Saving…" : "Finish"}
          </button>
        )}
      </div>
    </div>
  );
}
