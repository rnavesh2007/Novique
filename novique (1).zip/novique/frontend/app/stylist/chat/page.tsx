"use client";
import { useState, useRef, useEffect } from "react";
import { api } from "@/lib/api";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function StylistChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi, I'm your NOVIQUE stylist. Tell me what you're dressing for and I'll help you build the look." },
  ]);
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send() {
    if (!input.trim()) return;
    const userMessage = input;
    setMessages((m) => [...m, { role: "user", content: userMessage }]);
    setInput("");
    setLoading(true);
    try {
      const { reply, sessionId: sid } = await api<{ reply: string; sessionId: string }>("/ai/chat", {
        method: "POST",
        body: JSON.stringify({ sessionId, message: userMessage }),
      });
      setSessionId(sid);
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "Sorry — I couldn't reach the stylist service. Please sign in and try again." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-12 flex flex-col h-[calc(100vh-200px)]">
      <p className="label-tracked text-gold mb-2">AI Personal Shopper</p>
      <h1 className="font-display text-3xl mb-8">Stylist Chat</h1>

      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        {messages.map((m, i) => (
          <div key={i} className={`max-w-[80%] px-4 py-3 text-sm ${m.role === "user" ? "ml-auto bg-ink text-paper" : "bg-mist"}`}>
            {m.content}
          </div>
        ))}
        {loading && <div className="bg-mist max-w-[60%] px-4 py-3 text-sm text-ink/40">Thinking…</div>}
        <div ref={endRef} />
      </div>

      <div className="flex gap-3 mt-6 border-t border-ink/10 pt-6">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="e.g. I need an outfit for a beach wedding"
          className="flex-1 border border-ink/20 px-4 py-3 focus-ring"
        />
        <button onClick={send} disabled={loading} className="bg-ink text-paper px-6 py-3 label-tracked disabled:opacity-40 focus-ring">
          Send
        </button>
      </div>
    </div>
  );
}
