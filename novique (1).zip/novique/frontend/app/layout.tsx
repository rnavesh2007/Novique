import type { Metadata } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "../styles/globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const display = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-display",
});

const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://novique.example"),
  title: {
    default: "NOVIQUE — Style, Personalized by AI",
    template: "%s | NOVIQUE",
  },
  description:
    "NOVIQUE is an AI-powered personal fashion stylist and marketplace. Discover outfits, get compatibility-scored pairings, and shop complete looks instead of single products.",
  openGraph: {
    title: "NOVIQUE — Style, Personalized by AI",
    description: "Your AI fashion stylist. Complete outfits, not just products.",
    siteName: "NOVIQUE",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NOVIQUE — Style, Personalized by AI",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body className="font-body antialiased bg-paper text-ink">
        {/* Structured data: Organization, for SEO rich results */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "NOVIQUE",
              description: "AI-powered personal fashion stylist and marketplace.",
            }),
          }}
        />
        <Navbar />
        <main className="min-h-screen">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
