"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

interface Stats {
  userCount: number;
  productCount: number;
  orderCount: number;
  totalRevenue: number;
  pendingReturns: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api<Stats>("/admin/stats"), api<{ orders: any[] }>("/admin/orders")])
      .then(([s, o]) => {
        setStats(s);
        setOrders(o.orders);
      })
      .catch(() => setError("Sign in as an admin to view this dashboard."));
  }, []);

  async function updateStatus(id: string, status: string) {
    await api(`/admin/orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) });
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
  }

  if (error) return <div className="max-w-5xl mx-auto px-6 py-20 text-center text-ink/60">{error}</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <p className="label-tracked text-gold mb-2">Admin</p>
      <h1 className="font-display text-4xl mb-10">Dashboard</h1>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
          {[
            ["Customers", stats.userCount],
            ["Products", stats.productCount],
            ["Orders", stats.orderCount],
            ["Revenue", `$${Number(stats.totalRevenue).toFixed(2)}`],
            ["Pending Returns", stats.pendingReturns],
          ].map(([label, value]) => (
            <div key={label as string} className="border border-ink/10 p-5">
              <p className="label-tracked text-xs text-ink/50 mb-2">{label}</p>
              <p className="text-2xl font-display">{value}</p>
            </div>
          ))}
        </div>
      )}

      <p className="label-tracked text-gold mb-4">Recent Orders</p>
      <div className="divide-y divide-ink/10">
        {orders.map((o) => (
          <div key={o.id} className="flex items-center justify-between py-4 text-sm">
            <div>
              <p>{o.orderNumber}</p>
              <p className="text-ink/50">{o.user?.fullName} — ${Number(o.totalAmount).toFixed(2)}</p>
            </div>
            <select
              value={o.status}
              onChange={(e) => updateStatus(o.id, e.target.value)}
              className="border border-ink/20 px-3 py-2 focus-ring"
            >
              {["PENDING", "CONFIRMED", "PACKED", "SHIPPED", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED", "RETURNED"].map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}
