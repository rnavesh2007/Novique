import type { Config } from "tailwindcss";

// NOVIQUE design tokens — black / white / gold, minimalist luxury.
// See docs/BRAND_GUIDELINES.md for full rationale.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#000000",
        paper: "#FFFFFF",
        gold: {
          DEFAULT: "#D4AF37",
          dim: "#9C8027",
          light: "#E8CE7A",
        },
        graphite: "#1A1A1A",
        mist: "#F5F5F4",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      letterSpacing: {
        wider2: "0.18em",
      },
    },
  },
  plugins: [],
};
export default config;
